import { type ContextEngineMemoryV2Plugin } from "@openclaw-enhanced/bamdra-memory-context-engine";
import type { MemoryV2Config } from "@openclaw-enhanced/memory-core";
declare const TOOLS_REGISTERED_KEY: unique symbol;
declare const ENGINE_REGISTERED_KEY: unique symbol;
declare const BOOTSTRAP_STARTED_KEY: unique symbol;
type UnifiedPluginApi = {
    registerHook?: (events: string | string[], handler: (event: unknown) => unknown | Promise<unknown>, opts?: {
        name?: string;
        description?: string;
        priority?: number;
    }) => void;
    on?: (hookName: string, handler: (event: unknown, context: unknown) => unknown | Promise<unknown>, opts?: {
        priority?: number;
    }) => void;
    pluginConfig?: Partial<MemoryV2Config>;
    config?: Partial<MemoryV2Config>;
    plugin?: {
        config?: Partial<MemoryV2Config>;
    };
    runtime?: {
        getContextEngine?(): ContextEngineMemoryV2Plugin | null | undefined;
        contextEngine?: unknown;
        config?: unknown;
    };
    contextEngine?: unknown;
    registerContextEngine: (id: string, factory: (config: MemoryV2Config) => ContextEngineMemoryV2Plugin | Promise<ContextEngineMemoryV2Plugin>) => void;
    registerTool?<TParams>(definition: {
        name: string;
        description: string;
        parameters: Record<string, unknown>;
        execute(invocationId: string, params: TParams): Promise<{
            content: {
                type: "text";
                text: string;
            }[];
        }>;
    }): void;
    [TOOLS_REGISTERED_KEY]?: boolean;
    [ENGINE_REGISTERED_KEY]?: boolean;
    [BOOTSTRAP_STARTED_KEY]?: boolean;
};
export declare function register(api: UnifiedPluginApi): void;
export declare function activate(api: UnifiedPluginApi): Promise<void>;
export {};
//# sourceMappingURL=index.d.ts.map