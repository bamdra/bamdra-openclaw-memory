"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.ts
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  createUserBindPlugin: () => createUserBindPlugin,
  register: () => register
});
module.exports = __toCommonJS(index_exports);
var import_node_crypto = require("crypto");
var import_node_fs = require("fs");
var import_node_os = require("os");
var import_node_path = require("path");
var import_node_sqlite = require("node:sqlite");
var GLOBAL_API_KEY = "__OPENCLAW_BAMDRA_USER_BIND__";
var TABLES = {
  profiles: "bamdra_user_bind_profiles",
  bindings: "bamdra_user_bind_bindings",
  issues: "bamdra_user_bind_issues",
  audits: "bamdra_user_bind_audits"
};
var UserBindStore = class {
  constructor(dbPath, exportPath) {
    this.dbPath = dbPath;
    this.exportPath = exportPath;
    (0, import_node_fs.mkdirSync)((0, import_node_path.dirname)(dbPath), { recursive: true });
    (0, import_node_fs.mkdirSync)(exportPath, { recursive: true });
    this.db = new import_node_sqlite.DatabaseSync(dbPath);
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS ${TABLES.profiles} (
        user_id TEXT PRIMARY KEY,
        name TEXT,
        gender TEXT,
        email TEXT,
        avatar TEXT,
        nickname TEXT,
        preferences TEXT,
        personality TEXT,
        role TEXT,
        visibility TEXT NOT NULL DEFAULT 'private',
        source TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS ${TABLES.bindings} (
        binding_id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        channel_type TEXT NOT NULL,
        open_id TEXT,
        external_user_id TEXT,
        union_id TEXT,
        source TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        UNIQUE(channel_type, open_id)
      );
      CREATE TABLE IF NOT EXISTS ${TABLES.issues} (
        id TEXT PRIMARY KEY,
        kind TEXT NOT NULL,
        user_id TEXT,
        details TEXT NOT NULL,
        status TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS ${TABLES.audits} (
        id TEXT PRIMARY KEY,
        ts TEXT NOT NULL,
        agent_id TEXT,
        requester_user_id TEXT,
        tool_name TEXT NOT NULL,
        instruction TEXT NOT NULL,
        resolved_action TEXT NOT NULL,
        target_user_ids TEXT NOT NULL,
        decision TEXT NOT NULL,
        changed_fields TEXT NOT NULL
      );
    `);
  }
  db;
  close() {
    this.db.close();
  }
  getProfile(userId) {
    const row = this.db.prepare(`
      SELECT user_id, name, gender, email, avatar, nickname, preferences, personality, role, visibility, source, updated_at
      FROM ${TABLES.profiles} WHERE user_id = ?
    `).get(userId);
    return row ? mapProfileRow(row) : null;
  }
  findBinding(channelType, openId) {
    if (!openId) {
      return null;
    }
    const row = this.db.prepare(`
      SELECT user_id, source FROM ${TABLES.bindings}
      WHERE channel_type = ? AND open_id = ?
    `).get(channelType, openId);
    if (!row) {
      return null;
    }
    return {
      userId: row.user_id,
      source: row.source
    };
  }
  listIssues() {
    return this.db.prepare(`
      SELECT id, kind, user_id, details, status, updated_at
      FROM ${TABLES.issues}
      ORDER BY updated_at DESC
    `).all();
  }
  recordIssue(kind, details, userId = null) {
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const id = hashId(`${kind}:${userId ?? "none"}:${details}`);
    this.db.prepare(`
      INSERT INTO ${TABLES.issues} (id, kind, user_id, details, status, updated_at)
      VALUES (?, ?, ?, ?, 'open', ?)
      ON CONFLICT(id) DO UPDATE SET details = excluded.details, updated_at = excluded.updated_at
    `).run(id, kind, userId, details, now);
  }
  writeAudit(record) {
    this.db.prepare(`
      INSERT INTO ${TABLES.audits} (id, ts, agent_id, requester_user_id, tool_name, instruction, resolved_action, target_user_ids, decision, changed_fields)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      record.id,
      record.ts,
      record.agentId,
      record.requesterUserId,
      record.toolName,
      record.instruction,
      record.resolvedAction,
      JSON.stringify(record.targetUserIds),
      record.decision,
      JSON.stringify(record.changedFields)
    );
  }
  upsertIdentity(args) {
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const current = this.getProfile(args.userId);
    const next = {
      userId: args.userId,
      name: args.profilePatch.name ?? current?.name ?? null,
      gender: args.profilePatch.gender ?? current?.gender ?? null,
      email: args.profilePatch.email ?? current?.email ?? null,
      avatar: args.profilePatch.avatar ?? current?.avatar ?? null,
      nickname: args.profilePatch.nickname ?? current?.nickname ?? null,
      preferences: args.profilePatch.preferences ?? current?.preferences ?? null,
      personality: args.profilePatch.personality ?? current?.personality ?? null,
      role: args.profilePatch.role ?? current?.role ?? null,
      visibility: args.profilePatch.visibility ?? current?.visibility ?? "private",
      source: args.source,
      updatedAt: now
    };
    this.db.prepare(`
      INSERT INTO ${TABLES.profiles} (user_id, name, gender, email, avatar, nickname, preferences, personality, role, visibility, source, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(user_id) DO UPDATE SET
        name = excluded.name,
        gender = excluded.gender,
        email = excluded.email,
        avatar = excluded.avatar,
        nickname = excluded.nickname,
        preferences = excluded.preferences,
        personality = excluded.personality,
        role = excluded.role,
        visibility = excluded.visibility,
        source = excluded.source,
        updated_at = excluded.updated_at
    `).run(
      next.userId,
      next.name,
      next.gender,
      next.email,
      next.avatar,
      next.nickname,
      next.preferences,
      next.personality,
      next.role,
      next.visibility,
      next.source,
      next.updatedAt
    );
    const bindingId = hashId(`${args.channelType}:${args.openId ?? args.userId}`);
    this.db.prepare(`
      INSERT INTO ${TABLES.bindings} (binding_id, user_id, channel_type, open_id, external_user_id, union_id, source, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(channel_type, open_id) DO UPDATE SET
        user_id = excluded.user_id,
        source = excluded.source,
        updated_at = excluded.updated_at
    `).run(
      bindingId,
      args.userId,
      args.channelType,
      args.openId,
      args.userId,
      null,
      args.source,
      now
    );
    this.writeExports();
    return next;
  }
  updateProfile(userId, patch) {
    const current = this.getProfile(userId);
    if (!current) {
      throw new Error(`Unknown user ${userId}`);
    }
    return this.upsertIdentity({
      userId,
      channelType: "manual",
      openId: null,
      source: patch.source ?? "manual",
      profilePatch: {
        ...current,
        ...patch
      }
    });
  }
  mergeUsers(fromUserId, intoUserId) {
    const from = this.getProfile(fromUserId);
    const into = this.getProfile(intoUserId);
    if (!from || !into) {
      throw new Error("Both source and target users must exist before merge");
    }
    const merged = this.upsertIdentity({
      userId: intoUserId,
      channelType: "manual",
      openId: null,
      source: "admin-merge",
      profilePatch: {
        name: into.name ?? from.name,
        gender: into.gender ?? from.gender,
        email: into.email ?? from.email,
        avatar: into.avatar ?? from.avatar,
        nickname: into.nickname ?? from.nickname,
        preferences: into.preferences ?? from.preferences,
        personality: into.personality ?? from.personality,
        role: into.role ?? from.role,
        visibility: into.visibility
      }
    });
    this.db.prepare(`UPDATE ${TABLES.bindings} SET user_id = ?, updated_at = ? WHERE user_id = ?`).run(
      intoUserId,
      (/* @__PURE__ */ new Date()).toISOString(),
      fromUserId
    );
    this.db.prepare(`DELETE FROM ${TABLES.profiles} WHERE user_id = ?`).run(fromUserId);
    this.writeExports();
    return merged;
  }
  writeExports() {
    const profiles = this.db.prepare(`
      SELECT user_id, name, gender, email, avatar, nickname, preferences, personality, role, visibility, source, updated_at
      FROM ${TABLES.profiles}
      ORDER BY updated_at DESC
    `).all();
    const bindings = this.db.prepare(`
      SELECT user_id, channel_type, open_id, external_user_id, union_id, source, updated_at
      FROM ${TABLES.bindings}
      ORDER BY updated_at DESC
    `).all();
    (0, import_node_fs.writeFileSync)((0, import_node_path.join)(this.exportPath, "users.yaml"), renderYamlList(profiles), "utf8");
    (0, import_node_fs.writeFileSync)((0, import_node_path.join)(this.exportPath, "bindings.yaml"), renderYamlList(bindings), "utf8");
  }
};
var UserBindRuntime = class {
  constructor(host, inputConfig) {
    this.host = host;
    this.config = normalizeConfig(inputConfig);
    this.store = new UserBindStore(
      (0, import_node_path.join)(this.config.localStorePath, "profiles.sqlite"),
      this.config.exportPath
    );
  }
  store;
  config;
  sessionCache = /* @__PURE__ */ new Map();
  bindingCache = /* @__PURE__ */ new Map();
  close() {
    this.store.close();
  }
  register() {
    this.registerHooks();
    this.registerTools();
    exposeGlobalApi(this);
  }
  getIdentityForSession(sessionId) {
    return this.sessionCache.get(sessionId) ?? null;
  }
  async resolveFromContext(context) {
    const parsed = parseIdentityContext(context);
    if (parsed.sessionId && !parsed.channelType) {
      return this.sessionCache.get(parsed.sessionId) ?? null;
    }
    if (!parsed.sessionId || !parsed.channelType) {
      return null;
    }
    const cacheKey = `${parsed.channelType}:${parsed.openId ?? parsed.sessionId}`;
    const cached = this.bindingCache.get(cacheKey);
    if (cached && cached.expiresAt > Date.now()) {
      this.sessionCache.set(parsed.sessionId, cached.identity);
      return cached.identity;
    }
    const binding = this.store.findBinding(parsed.channelType, parsed.openId);
    let userId = binding?.userId ?? null;
    let source = binding?.source ?? "local";
    if (!userId && parsed.channelType === "feishu" && parsed.openId) {
      const remote = await this.tryResolveFeishuUser(parsed.openId);
      if (remote?.userId) {
        userId = remote.userId;
        source = remote.source;
      } else {
        this.store.recordIssue("feishu-resolution", `Failed to resolve real user id for ${parsed.openId}`);
      }
    }
    if (!userId) {
      userId = `${parsed.channelType}:${parsed.openId ?? parsed.sessionId}`;
      source = "synthetic-fallback";
    }
    const profile = this.store.upsertIdentity({
      userId,
      channelType: parsed.channelType,
      openId: parsed.openId,
      source,
      profilePatch: {
        name: parsed.senderName
      }
    });
    const identity = {
      sessionId: parsed.sessionId,
      userId,
      channelType: parsed.channelType,
      senderOpenId: parsed.openId,
      senderName: parsed.senderName,
      source,
      resolvedAt: (/* @__PURE__ */ new Date()).toISOString(),
      profile
    };
    this.sessionCache.set(parsed.sessionId, identity);
    this.bindingCache.set(cacheKey, {
      expiresAt: Date.now() + this.config.cacheTtlMs,
      identity
    });
    return identity;
  }
  async getMyProfile(context) {
    const identity = await this.requireCurrentIdentity(context);
    return identity.profile;
  }
  async updateMyProfile(context, patch) {
    const identity = await this.requireCurrentIdentity(context);
    const updated = this.store.updateProfile(identity.userId, {
      ...patch,
      source: "self-update"
    });
    const nextIdentity = {
      ...identity,
      profile: updated
    };
    this.sessionCache.set(identity.sessionId, nextIdentity);
    return updated;
  }
  async refreshMyBinding(context) {
    const identity = await this.requireCurrentIdentity(context);
    this.bindingCache.delete(`${identity.channelType}:${identity.senderOpenId ?? identity.sessionId}`);
    const refreshed = await this.resolveFromContext({
      sessionId: identity.sessionId,
      sender: { id: identity.senderOpenId, name: identity.senderName },
      channel: { type: identity.channelType }
    });
    if (!refreshed) {
      throw new Error("Unable to refresh binding for current session");
    }
    return refreshed;
  }
  async adminInstruction(toolName, instruction, context) {
    const requester = await this.resolveFromContext(context);
    const agentId = getAgentIdFromContext(context);
    if (!agentId || !this.config.adminAgents.includes(agentId)) {
      this.store.writeAudit({
        id: hashId(`${toolName}:${instruction}:${Date.now()}`),
        ts: (/* @__PURE__ */ new Date()).toISOString(),
        agentId,
        requesterUserId: requester?.userId ?? null,
        toolName,
        instruction,
        resolvedAction: "deny",
        targetUserIds: [],
        decision: "denied",
        changedFields: []
      });
      throw new Error("access denied: cross-user profile access is not allowed");
    }
    const parsed = parseAdminInstruction(instruction);
    const targetUserIds = parsed.userIds;
    let result;
    const changedFields = [];
    if (parsed.action === "query") {
      result = targetUserIds.map((userId) => this.store.getProfile(userId)).filter(Boolean);
    } else if (parsed.action === "edit") {
      if (targetUserIds.length !== 1) {
        throw new Error("admin edit requires exactly one target user");
      }
      result = this.store.updateProfile(targetUserIds[0], parsed.patch);
      changedFields.push(...Object.keys(parsed.patch));
    } else if (parsed.action === "merge") {
      if (targetUserIds.length !== 2) {
        throw new Error("admin merge requires source and target user ids");
      }
      result = this.store.mergeUsers(targetUserIds[0], targetUserIds[1]);
      changedFields.push("user_merge");
    } else if (parsed.action === "list_issues") {
      result = this.store.listIssues();
    } else if (parsed.action === "sync") {
      result = {
        synced: targetUserIds.map((userId) => ({
          userId,
          ok: true
        }))
      };
    } else {
      throw new Error("unsupported admin instruction");
    }
    this.store.writeAudit({
      id: hashId(`${toolName}:${instruction}:${Date.now()}`),
      ts: (/* @__PURE__ */ new Date()).toISOString(),
      agentId,
      requesterUserId: requester?.userId ?? null,
      toolName,
      instruction,
      resolvedAction: parsed.action,
      targetUserIds,
      decision: "allowed",
      changedFields
    });
    return result;
  }
  registerHooks() {
    this.host.registerHook?.(
      ["message:received", "message:preprocessed"],
      async (event) => {
        await this.resolveFromContext(event);
      },
      {
        name: "bamdra-user-bind-resolve",
        description: "Resolve runtime identity from channel sender metadata"
      }
    );
    this.host.on?.("before_prompt_build", async (_event, context) => {
      const identity = await this.resolveFromContext(context);
      if (!identity) {
        return;
      }
      return {
        context: [
          {
            type: "text",
            text: renderIdentityContext(identity)
          }
        ]
      };
    });
  }
  registerTools() {
    const registerTool = this.host.registerTool?.bind(this.host);
    if (!registerTool) {
      return;
    }
    registerTool({
      name: "user_bind_get_my_profile",
      description: "Get the current user's bound profile",
      parameters: {
        type: "object",
        additionalProperties: false,
        properties: {
          sessionId: { type: "string" }
        }
      },
      execute: async (_id, params) => asTextResult(await this.getMyProfile(params))
    });
    registerTool({
      name: "user_bind_update_my_profile",
      description: "Update the current user's own profile fields",
      parameters: {
        type: "object",
        additionalProperties: false,
        required: ["sessionId"],
        properties: {
          sessionId: { type: "string" },
          nickname: { type: "string" },
          preferences: { type: "string" },
          personality: { type: "string" },
          role: { type: "string" }
        }
      },
      execute: async (_id, params) => asTextResult(await this.updateMyProfile(params, sanitizeProfilePatch(params)))
    });
    registerTool({
      name: "user_bind_refresh_my_binding",
      description: "Refresh the current user's identity binding",
      parameters: {
        type: "object",
        additionalProperties: false,
        properties: {
          sessionId: { type: "string" }
        }
      },
      execute: async (_id, params) => asTextResult(await this.refreshMyBinding(params))
    });
    for (const toolName of [
      "user_bind_admin_query",
      "user_bind_admin_edit",
      "user_bind_admin_merge",
      "user_bind_admin_list_issues",
      "user_bind_admin_sync"
    ]) {
      registerTool({
        name: toolName,
        description: `Administrative natural-language tool for ${toolName.replace("user_bind_admin_", "")}`,
        parameters: {
          type: "object",
          additionalProperties: false,
          required: ["instruction"],
          properties: {
            instruction: { type: "string" },
            sessionId: { type: "string" },
            agentId: { type: "string" }
          }
        },
        execute: async (_id, params) => asTextResult(await this.adminInstruction(toolName, String(params.instruction ?? ""), params))
      });
    }
  }
  async requireCurrentIdentity(context) {
    const identity = await this.resolveFromContext(context);
    if (!identity) {
      throw new Error("Unable to resolve current user identity");
    }
    return identity;
  }
  async tryResolveFeishuUser(openId) {
    const executor = this.host.callTool ?? this.host.invokeTool;
    if (typeof executor !== "function") {
      return null;
    }
    try {
      const result = await executor.call(this.host, "feishu_user_get", {
        user_id_type: "open_id",
        user_id: openId
      });
      const candidate = extractDeepString(result, [
        ["data", "user", "user_id"],
        ["user", "user_id"],
        ["data", "user_id"]
      ]);
      return candidate ? { userId: candidate, source: "feishu-api" } : null;
    } catch (error) {
      this.store.recordIssue("feishu-resolution", error instanceof Error ? error.message : String(error));
      return null;
    }
  }
};
function createUserBindPlugin(api) {
  return new UserBindRuntime(api, api.pluginConfig ?? api.config ?? api.plugin?.config);
}
function register(api) {
  createUserBindPlugin(api).register();
}
async function activate(api) {
  createUserBindPlugin(api).register();
}
function normalizeConfig(input) {
  const root = (0, import_node_path.join)((0, import_node_os.homedir)(), ".openclaw", "data", "bamdra-user-bind");
  return {
    enabled: input?.enabled ?? true,
    localStorePath: input?.localStorePath ?? root,
    exportPath: input?.exportPath ?? (0, import_node_path.join)(root, "exports"),
    cacheTtlMs: input?.cacheTtlMs ?? 30 * 60 * 1e3,
    adminAgents: input?.adminAgents ?? []
  };
}
function exposeGlobalApi(runtime) {
  globalThis[GLOBAL_API_KEY] = {
    getIdentityForSession(sessionId) {
      return runtime.getIdentityForSession(sessionId);
    },
    async resolveIdentity(context) {
      return runtime.resolveFromContext(context);
    }
  };
}
function mapProfileRow(row) {
  return {
    userId: String(row.user_id),
    name: asNullableString(row.name),
    gender: asNullableString(row.gender),
    email: asNullableString(row.email),
    avatar: asNullableString(row.avatar),
    nickname: asNullableString(row.nickname),
    preferences: asNullableString(row.preferences),
    personality: asNullableString(row.personality),
    role: asNullableString(row.role),
    visibility: row.visibility === "shared" ? "shared" : "private",
    source: String(row.source ?? "local"),
    updatedAt: String(row.updated_at ?? (/* @__PURE__ */ new Date(0)).toISOString())
  };
}
function parseIdentityContext(context) {
  const record = context && typeof context === "object" ? context : {};
  const sender = record.sender && typeof record.sender === "object" ? record.sender : {};
  const message = record.message && typeof record.message === "object" ? record.message : {};
  const sessionId = asNullableString(record.sessionId) ?? asNullableString(record.sessionKey) ?? asNullableString(record.session?.id) ?? asNullableString(record.context?.sessionId);
  const channelType = asNullableString(record.channelType) ?? asNullableString(record.channel?.type) ?? asNullableString(message.channel?.type) ?? asNullableString(record.provider);
  const openId = asNullableString(sender.id) ?? asNullableString(sender.open_id) ?? asNullableString(sender.openId) ?? asNullableString(message.sender?.id);
  const senderName = asNullableString(sender.name) ?? asNullableString(sender.display_name) ?? asNullableString(message.sender?.name);
  return {
    sessionId,
    channelType,
    openId,
    senderName
  };
}
function getAgentIdFromContext(context) {
  const record = context && typeof context === "object" ? context : {};
  return asNullableString(record.agentId) ?? asNullableString(record.agent?.id);
}
function sanitizeProfilePatch(params) {
  return {
    nickname: asNullableString(params.nickname),
    preferences: asNullableString(params.preferences),
    personality: asNullableString(params.personality),
    role: asNullableString(params.role)
  };
}
function parseAdminInstruction(instruction) {
  const normalized = instruction.trim();
  if (/issue|问题|失败/i.test(normalized)) {
    return { action: "list_issues", userIds: [], patch: {} };
  }
  if (/merge|合并/i.test(normalized)) {
    const userIds = normalized.match(/user[:=]([A-Za-z0-9:_-]+)/g)?.map((item) => item.split(/[:=]/)[1]) ?? [];
    return { action: "merge", userIds, patch: {} };
  }
  if (/sync|重同步|同步/i.test(normalized)) {
    return { action: "sync", userIds: extractUserIds(normalized), patch: {} };
  }
  if (/edit|修改|改成|更新/i.test(normalized)) {
    return {
      action: "edit",
      userIds: extractUserIds(normalized),
      patch: extractProfilePatch(normalized)
    };
  }
  return {
    action: "query",
    userIds: extractUserIds(normalized),
    patch: {}
  };
}
function extractUserIds(input) {
  return [...input.matchAll(/(?:user[:=]|用户[:：]?)([A-Za-z0-9:_-]+)/g)].map((match) => match[1]);
}
function extractProfilePatch(input) {
  const patch = {};
  const nickname = input.match(/(?:nickname|称呼)[=:： ]([^,，]+)$/i) ?? input.match(/(?:nickname|称呼)[=:： ]([^,，]+)/i);
  const role = input.match(/(?:role|职责|角色)[=:： ]([^,，]+)/i);
  const preferences = input.match(/(?:preferences|偏好)[=:： ]([^,，]+)/i);
  const personality = input.match(/(?:personality|性格)[=:： ]([^,，]+)/i);
  if (nickname) {
    patch.nickname = nickname[1].trim();
  }
  if (role) {
    patch.role = role[1].trim();
  }
  if (preferences) {
    patch.preferences = preferences[1].trim();
  }
  if (personality) {
    patch.personality = personality[1].trim();
  }
  return patch;
}
function renderIdentityContext(identity) {
  const lines = [
    `Resolved user id: ${identity.userId}`,
    `Channel: ${identity.channelType}`
  ];
  if (identity.profile.name) {
    lines.push(`Name: ${identity.profile.name}`);
  }
  if (identity.profile.nickname) {
    lines.push(`Preferred address: ${identity.profile.nickname}`);
  }
  if (identity.profile.preferences) {
    lines.push(`Preferences: ${identity.profile.preferences}`);
  }
  if (identity.profile.personality) {
    lines.push(`Personality: ${identity.profile.personality}`);
  }
  if (identity.profile.role) {
    lines.push(`Role: ${identity.profile.role}`);
  }
  return lines.join("\n");
}
function renderYamlList(rows) {
  if (rows.length === 0) {
    return "[]\n";
  }
  return `${rows.map((row) => {
    const lines = ["-"];
    for (const [key, value] of Object.entries(row)) {
      const rendered = value == null ? "null" : JSON.stringify(value);
      lines.push(`  ${key}: ${rendered}`);
    }
    return lines.join("\n");
  }).join("\n")}
`;
}
function extractDeepString(value, paths) {
  for (const path of paths) {
    let current = value;
    for (const key of path) {
      if (!current || typeof current !== "object") {
        current = null;
        break;
      }
      current = current[key];
    }
    const candidate = asNullableString(current);
    if (candidate) {
      return candidate;
    }
  }
  return null;
}
function asTextResult(value) {
  return {
    content: [
      {
        type: "text",
        text: typeof value === "string" ? value : JSON.stringify(value, null, 2)
      }
    ]
  };
}
function asNullableString(value) {
  return typeof value === "string" && value.trim().length > 0 ? value.trim() : null;
}
function hashId(value) {
  return (0, import_node_crypto.createHash)("sha1").update(value).digest("hex").slice(0, 24);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  activate,
  createUserBindPlugin,
  register
});
