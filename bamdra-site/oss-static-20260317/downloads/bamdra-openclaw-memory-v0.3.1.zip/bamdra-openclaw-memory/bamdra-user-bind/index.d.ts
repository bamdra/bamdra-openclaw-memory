export interface UserProfile {
    userId: string;
    name: string | null;
    gender: string | null;
    email: string | null;
    avatar: string | null;
    nickname: string | null;
    preferences: string | null;
    personality: string | null;
    role: string | null;
    visibility: "private" | "shared";
    source: string;
    updatedAt: string;
}
export interface ResolvedIdentity {
    sessionId: string;
    userId: string;
    channelType: string;
    senderOpenId: string | null;
    senderName: string | null;
    source: string;
    resolvedAt: string;
    profile: UserProfile;
}
export interface UserBindConfig {
    enabled: boolean;
    localStorePath: string;
    exportPath: string;
    cacheTtlMs: number;
    adminAgents: string[];
}
interface UserBindToolResult {
    content: Array<{
        type: "text";
        text: string;
    }>;
}
interface ToolDefinition<TParams> {
    name: string;
    description: string;
    parameters: Record<string, unknown>;
    execute(invocationId: string, params: TParams): Promise<UserBindToolResult>;
}
interface HookApi {
    registerHook?: (events: string | string[], handler: (event: unknown) => unknown | Promise<unknown>, opts?: {
        name?: string;
        description?: string;
        priority?: number;
    }) => void;
    on?: (hookName: string, handler: (event: unknown, context: unknown) => unknown | Promise<unknown>, opts?: {
        priority?: number;
    }) => void;
    registerTool?<TParams>(definition: ToolDefinition<TParams>): void;
    callTool?<TParams>(name: string, params: TParams): Promise<unknown>;
    invokeTool?<TParams>(name: string, params: TParams): Promise<unknown>;
    pluginConfig?: Partial<UserBindConfig>;
    config?: Partial<UserBindConfig>;
    plugin?: {
        config?: Partial<UserBindConfig>;
    };
}
declare class UserBindRuntime {
    private readonly host;
    private readonly store;
    private readonly config;
    private readonly sessionCache;
    private readonly bindingCache;
    constructor(host: HookApi, inputConfig: Partial<UserBindConfig> | undefined);
    close(): void;
    register(): void;
    getIdentityForSession(sessionId: string): ResolvedIdentity | null;
    resolveFromContext(context: unknown): Promise<ResolvedIdentity | null>;
    getMyProfile(context: unknown): Promise<UserProfile>;
    updateMyProfile(context: unknown, patch: Partial<UserProfile>): Promise<UserProfile>;
    refreshMyBinding(context: unknown): Promise<ResolvedIdentity>;
    adminInstruction(toolName: string, instruction: string, context: unknown): Promise<unknown>;
    private registerHooks;
    private registerTools;
    private requireCurrentIdentity;
    private tryResolveFeishuUser;
}
export declare function createUserBindPlugin(api: HookApi): UserBindRuntime;
export declare function register(api: HookApi): void;
export declare function activate(api: HookApi): Promise<void>;
export {};
//# sourceMappingURL=index.d.ts.map