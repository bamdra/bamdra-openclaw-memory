export interface MemoryVectorConfig {
    enabled: boolean;
    markdownRoot: string;
    indexPath: string;
    dimensions: number;
}
interface ToolDefinition<TParams> {
    name: string;
    description: string;
    parameters: Record<string, unknown>;
    execute(invocationId: string, params: TParams): Promise<{
        content: Array<{
            type: "text";
            text: string;
        }>;
    }>;
}
interface VectorPluginHost {
    registerTool?<TParams>(definition: ToolDefinition<TParams>): void;
    pluginConfig?: Partial<MemoryVectorConfig>;
    config?: Partial<MemoryVectorConfig>;
    plugin?: {
        config?: Partial<MemoryVectorConfig>;
    };
}
export declare function register(api: VectorPluginHost): void;
export declare function activate(api: VectorPluginHost): Promise<void>;
export {};
//# sourceMappingURL=index.d.ts.map