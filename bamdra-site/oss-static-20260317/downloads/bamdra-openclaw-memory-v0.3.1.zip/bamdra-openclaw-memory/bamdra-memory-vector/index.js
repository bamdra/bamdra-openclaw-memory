"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.ts
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  register: () => register
});
module.exports = __toCommonJS(index_exports);
var import_node_crypto = require("crypto");
var import_node_fs = require("fs");
var import_node_os = require("os");
var import_node_path = require("path");
var GLOBAL_VECTOR_API_KEY = "__OPENCLAW_BAMDRA_MEMORY_VECTOR__";
var LocalVectorIndex = class {
  config;
  records = /* @__PURE__ */ new Map();
  constructor(inputConfig) {
    this.config = normalizeConfig(inputConfig);
    (0, import_node_fs.mkdirSync)((0, import_node_path.dirname)(this.config.indexPath), { recursive: true });
    (0, import_node_fs.mkdirSync)(this.config.markdownRoot, { recursive: true });
    this.load();
  }
  upsert(args) {
    const id = hashId(`${args.userId ?? "shared"}:${args.sourcePath}:${args.title}`);
    const record = {
      id,
      userId: args.userId,
      sessionId: args.sessionId,
      topicId: args.topicId,
      sourcePath: args.sourcePath,
      title: args.title,
      text: args.text,
      tags: args.tags ?? [],
      embedding: embed(`${args.title}
${args.text}`, this.config.dimensions),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    this.records.set(id, record);
    const markdownPath = (0, import_node_path.join)(this.config.markdownRoot, args.sourcePath);
    (0, import_node_fs.mkdirSync)((0, import_node_path.dirname)(markdownPath), { recursive: true });
    (0, import_node_fs.writeFileSync)(markdownPath, `# ${args.title}

${args.text}
`, "utf8");
    this.flush();
  }
  search(args) {
    const limit = args.limit ?? 5;
    const queryEmbedding = embed(args.query, this.config.dimensions);
    return [...this.records.values()].filter((record) => {
      if (args.userId == null) {
        return record.userId == null;
      }
      return record.userId === args.userId;
    }).map((record) => ({
      id: record.id,
      userId: record.userId,
      topicId: record.topicId,
      sessionId: record.sessionId,
      sourcePath: record.sourcePath,
      title: record.title,
      text: record.text,
      tags: record.tags,
      score: cosineSimilarity(queryEmbedding, record.embedding),
      matchReasons: inferMatchReasons(args.query, record),
      source: "vector"
    })).sort((a, b) => b.score - a.score).slice(0, limit);
  }
  flush() {
    const payload = JSON.stringify([...this.records.values()], null, 2);
    (0, import_node_fs.writeFileSync)(this.config.indexPath, `${payload}
`, "utf8");
  }
  load() {
    if (!(0, import_node_fs.existsSync)(this.config.indexPath)) {
      return;
    }
    const payload = JSON.parse((0, import_node_fs.readFileSync)(this.config.indexPath, "utf8"));
    for (const record of payload) {
      this.records.set(record.id, record);
    }
  }
};
function register(api) {
  const runtime = new LocalVectorIndex(api.pluginConfig ?? api.config ?? api.plugin?.config);
  exposeVectorApi(runtime);
  api.registerTool?.({
    name: "memory_vector_search",
    description: "Search the current user's vector memory index",
    parameters: {
      type: "object",
      additionalProperties: false,
      required: ["query"],
      properties: {
        query: { type: "string" },
        userId: { type: ["string", "null"] },
        topicId: { type: ["string", "null"] },
        limit: { type: "integer", minimum: 1, maximum: 20 }
      }
    },
    async execute(_id, params) {
      return {
        content: [
          {
            type: "text",
            text: JSON.stringify(runtime.search({
              query: String(params.query ?? ""),
              userId: typeof params.userId === "string" ? params.userId : null,
              topicId: typeof params.topicId === "string" ? params.topicId : null,
              limit: typeof params.limit === "number" ? params.limit : void 0
            }), null, 2)
          }
        ]
      };
    }
  });
}
async function activate(api) {
  register(api);
}
function exposeVectorApi(runtime) {
  globalThis[GLOBAL_VECTOR_API_KEY] = {
    upsertMemoryRecord(args) {
      runtime.upsert(args);
    },
    search(args) {
      return runtime.search(args);
    }
  };
}
function normalizeConfig(input) {
  const root = (0, import_node_path.join)((0, import_node_os.homedir)(), ".openclaw", "memory", "vector");
  return {
    enabled: input?.enabled ?? true,
    markdownRoot: input?.markdownRoot ?? (0, import_node_path.join)(root, "markdown"),
    indexPath: input?.indexPath ?? (0, import_node_path.join)(root, "index.json"),
    dimensions: input?.dimensions ?? 64
  };
}
function embed(text, dimensions) {
  const vector = Array.from({ length: dimensions }, () => 0);
  const tokens = text.toLowerCase().split(/[^a-z0-9_\u4e00-\u9fff]+/i).filter(Boolean);
  for (const token of tokens) {
    const digest = (0, import_node_crypto.createHash)("sha1").update(token).digest();
    const index = digest[0] % dimensions;
    vector[index] += 1;
  }
  const magnitude = Math.sqrt(vector.reduce((sum, item) => sum + item * item, 0)) || 1;
  return vector.map((item) => item / magnitude);
}
function cosineSimilarity(a, b) {
  let sum = 0;
  for (let index = 0; index < Math.min(a.length, b.length); index += 1) {
    sum += a[index] * b[index];
  }
  return Number(sum.toFixed(6));
}
function inferMatchReasons(query, record) {
  const reasons = [];
  const normalized = query.toLowerCase();
  if (record.title.toLowerCase().includes(normalized)) {
    reasons.push("title");
  }
  if (record.text.toLowerCase().includes(normalized)) {
    reasons.push("text");
  }
  if (reasons.length === 0) {
    reasons.push("semantic");
  }
  return reasons;
}
function hashId(value) {
  return (0, import_node_crypto.createHash)("sha1").update(value).digest("hex").slice(0, 24);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  activate,
  register
});
