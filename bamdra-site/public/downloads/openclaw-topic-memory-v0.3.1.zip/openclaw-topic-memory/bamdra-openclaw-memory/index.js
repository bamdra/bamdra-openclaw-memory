"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.ts
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  register: () => register
});
module.exports = __toCommonJS(index_exports);

// ../../../node_modules/.pnpm/tsup@8.5.1_typescript@5.9.3/node_modules/tsup/assets/cjs_shims.js
var getImportMetaUrl = () => typeof document === "undefined" ? new URL(`file:${__filename}`).href : document.currentScript && document.currentScript.tagName.toUpperCase() === "SCRIPT" ? document.currentScript.src : new URL("main.js", document.baseURI).href;
var importMetaUrl = /* @__PURE__ */ getImportMetaUrl();

// ../../packages/context-assembler/src/index.ts
var ContextAssembler = class {
  constructor(config) {
    this.config = config;
  }
  assemble(input) {
    const sections = [];
    if (input.topic) {
      sections.push({
        kind: "topic",
        content: `Topic: ${input.topic.title}
Labels: ${joinList(input.topic.labels)}`
      });
      if (this.config.contextAssembly?.includeTopicShortSummary !== false) {
        sections.push({
          kind: "summary",
          content: input.topic.summaryShort || "(no short summary yet)"
        });
      }
      if (this.config.contextAssembly?.includeOpenLoops !== false && input.topic.openLoops.length > 0) {
        sections.push({
          kind: "open_loops",
          content: input.topic.openLoops.map((item) => `- ${item}`).join("\n")
        });
      }
    }
    const facts = [
      ...limitFacts(
        input.alwaysFacts,
        this.config.contextAssembly?.alwaysFactLimit ?? 12
      ),
      ...limitFacts(
        input.topicFacts,
        this.config.contextAssembly?.topicFactLimit ?? 16
      )
    ];
    if (facts.length > 0) {
      sections.push({
        kind: "facts",
        content: facts.map((fact) => {
          const prefix = fact.sensitivity === "secret_ref" ? "[secret-ref]" : `[${fact.category}]`;
          return `${prefix} ${fact.key}: ${fact.value}`;
        }).join("\n")
      });
    }
    if (input.recentMessages.length > 0) {
      sections.push({
        kind: "recent_messages",
        content: input.recentMessages.map(({ message }) => `${message.role}: ${message.text}`).join("\n")
      });
    }
    return {
      sessionId: input.sessionId,
      topicId: input.topic?.id ?? null,
      text: sections.map((section) => `[${section.kind}]
${section.content}`).join("\n\n"),
      sections
    };
  }
};
function joinList(values) {
  return values.length > 0 ? values.join(", ") : "(none)";
}
function limitFacts(values, limit) {
  return values.slice(0, Math.max(0, limit));
}

// ../../packages/fact-extractor/src/index.ts
var FactExtractor = class {
  constructor(_config) {
    this._config = _config;
  }
  extract(input) {
    const candidates = [];
    candidates.push(...extractNodeVersion(input));
    candidates.push(...extractAccountLikeFacts(input));
    candidates.push(...extractConstraintFacts(input));
    candidates.push(...extractPreferenceFacts(input));
    return dedupeCandidates(candidates);
  }
};
function extractNodeVersion(input) {
  const match = input.text.match(/\bnode(?:\.js)?\s*v?(\d+\.\d+\.\d+)\b/i);
  if (!match) {
    return [];
  }
  return [
    {
      category: "environment",
      key: "runtime.node",
      value: `Node ${match[1]}`,
      sensitivity: "normal",
      recallPolicy: "always",
      scope: "global",
      confidence: 0.95,
      tags: ["runtime", "node"]
    }
  ];
}
function extractAccountLikeFacts(input) {
  const lower = input.text.toLowerCase();
  const candidates = [];
  if (!/(账号|账户|account|appid|appsecret|token|apikey|api key)/i.test(input.text)) {
    return candidates;
  }
  const scope = input.topic ? `topic:${input.topic.id}` : "shared";
  const labels = input.topic?.labels ?? [];
  if (/(appid|appsecret|token|apikey|api key)/i.test(input.text)) {
    candidates.push({
      category: "security",
      key: "secret.reference",
      value: abbreviate(input.text),
      sensitivity: "secret_ref",
      recallPolicy: "topic_bound",
      scope,
      confidence: 0.8,
      tags: [...labels, "security", "account"]
    });
  }
  if (/(账号|账户|account)/i.test(input.text)) {
    candidates.push({
      category: "account",
      key: `account.note.${stableKeyFragment(input.text)}`,
      value: abbreviate(input.text),
      sensitivity: "sensitive",
      recallPolicy: "topic_bound",
      scope,
      confidence: 0.72,
      tags: [...labels, "account"]
    });
  }
  return candidates;
}
function extractConstraintFacts(input) {
  if (!/(必须|不能|不要|禁止|只能|must|cannot|can't|should not|do not)/i.test(input.text)) {
    return [];
  }
  return [
    {
      category: "constraint",
      key: `constraint.${stableKeyFragment(input.text)}`,
      value: abbreviate(input.text),
      sensitivity: "normal",
      recallPolicy: "topic_bound",
      scope: input.topic ? `topic:${input.topic.id}` : "shared",
      confidence: 0.82,
      tags: [...input.topic?.labels ?? [], "constraint"]
    }
  ];
}
function extractPreferenceFacts(input) {
  if (!/(偏好|喜欢|不喜欢|prefer|preference|默认)/i.test(input.text)) {
    return [];
  }
  return [
    {
      category: "preference",
      key: `preference.${stableKeyFragment(input.text)}`,
      value: abbreviate(input.text),
      sensitivity: "normal",
      recallPolicy: "always",
      scope: "shared",
      confidence: 0.76,
      tags: [...input.topic?.labels ?? [], "preference"]
    }
  ];
}
function dedupeCandidates(candidates) {
  const seen = /* @__PURE__ */ new Set();
  return candidates.filter((candidate) => {
    const dedupeKey = `${candidate.scope}:${candidate.key}:${candidate.value}`;
    if (seen.has(dedupeKey)) {
      return false;
    }
    seen.add(dedupeKey);
    return true;
  });
}
function abbreviate(text) {
  const compact = text.trim().replace(/\s+/g, " ");
  return compact.length <= 120 ? compact : `${compact.slice(0, 120)}...`;
}
function stableKeyFragment(text) {
  return text.toLowerCase().replace(/[^a-z0-9\u4e00-\u9fff]+/gi, ".").replace(/^\.+|\.+$/g, "").slice(0, 48) || "note";
}

// ../../packages/memory-cache-memory/src/index.ts
function logCacheEvent(event, details = {}) {
  try {
    console.info("[bamdra-openclaw-memory-cache]", event, JSON.stringify(details));
  } catch {
    console.info("[bamdra-openclaw-memory-cache]", event);
  }
}
var InMemoryCacheStore = class {
  sessionState = /* @__PURE__ */ new Map();
  maxSessions;
  constructor(config = { provider: "memory" }) {
    this.maxSessions = config.maxSessions ?? 128;
    logCacheEvent("init", { provider: "memory", maxSessions: this.maxSessions });
  }
  async getActiveTopicId(sessionId) {
    const activeTopicId = this.sessionState.get(sessionId)?.activeTopicId ?? null;
    logCacheEvent("get-active-topic", {
      sessionId,
      hit: activeTopicId !== null,
      activeTopicId
    });
    return activeTopicId;
  }
  async setActiveTopicId(sessionId, topicId) {
    const current = this.sessionState.get(sessionId);
    await this.setSessionState(sessionId, {
      activeTopicId: topicId,
      updatedAt: current?.updatedAt ?? (/* @__PURE__ */ new Date()).toISOString()
    });
  }
  async getSessionState(sessionId) {
    const state = this.sessionState.get(sessionId) ?? null;
    logCacheEvent("get-session-state", {
      sessionId,
      hit: state !== null,
      activeTopicId: state?.activeTopicId ?? null
    });
    return state;
  }
  async setSessionState(sessionId, state) {
    if (!this.sessionState.has(sessionId) && this.sessionState.size >= this.maxSessions) {
      const oldestKey = this.sessionState.keys().next().value;
      if (oldestKey) {
        this.sessionState.delete(oldestKey);
        logCacheEvent("evict-session-state", {
          sessionId: oldestKey,
          sizeAfter: this.sessionState.size
        });
      }
    }
    this.sessionState.set(sessionId, state);
    logCacheEvent("set-session-state", {
      sessionId,
      activeTopicId: state.activeTopicId,
      updatedAt: state.updatedAt,
      size: this.sessionState.size
    });
  }
  async deleteSessionState(sessionId) {
    this.sessionState.delete(sessionId);
    logCacheEvent("delete-session-state", {
      sessionId,
      size: this.sessionState.size
    });
  }
  async close() {
  }
};

// ../../packages/memory-sqlite/src/index.ts
var import_node_fs = require("node:fs");
var import_promises = require("node:fs/promises");
var import_node_path = require("node:path");
var import_node_sqlite = require("node:sqlite");
var import_node_url = require("node:url");
var SCHEMA_VERSION = 1;
var MemorySqliteStore = class {
  constructor(options) {
    this.options = options;
    (0, import_node_fs.mkdirSync)((0, import_node_path.dirname)(options.path), { recursive: true });
    this.db = new import_node_sqlite.DatabaseSync(options.path);
  }
  db;
  async getSchemaVersion() {
    return SCHEMA_VERSION;
  }
  async applyMigrations() {
    const schemaSql = await loadSchemaSql();
    this.db.exec(schemaSql);
  }
  async close() {
    this.db.close();
  }
  async upsertMessage(record) {
    this.db.prepare(
      `INSERT INTO messages (
          id,
          session_id,
          turn_id,
          parent_turn_id,
          role,
          event_type,
          text,
          ts,
          raw_json
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
          session_id = excluded.session_id,
          turn_id = excluded.turn_id,
          parent_turn_id = excluded.parent_turn_id,
          role = excluded.role,
          event_type = excluded.event_type,
          text = excluded.text,
          ts = excluded.ts,
          raw_json = excluded.raw_json`
    ).run(
      record.id,
      record.sessionId,
      record.turnId,
      record.parentTurnId,
      record.role,
      record.eventType,
      record.text,
      record.ts,
      record.rawJson
    );
  }
  async getSessionState(sessionId) {
    const row = this.db.prepare(
      `SELECT session_id, active_topic_id, last_compacted_at, last_turn_id, updated_at
         FROM session_state
         WHERE session_id = ?`
    ).get(sessionId);
    return row ? mapSessionStateRow(row) : null;
  }
  async upsertSessionState(record) {
    this.db.prepare(
      `INSERT INTO session_state (
          session_id,
          active_topic_id,
          last_compacted_at,
          last_turn_id,
          updated_at
        ) VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(session_id) DO UPDATE SET
          active_topic_id = excluded.active_topic_id,
          last_compacted_at = excluded.last_compacted_at,
          last_turn_id = excluded.last_turn_id,
          updated_at = excluded.updated_at`
    ).run(
      record.sessionId,
      record.activeTopicId,
      record.lastCompactedAt,
      record.lastTurnId,
      record.updatedAt
    );
  }
  async listTopics(sessionId) {
    const rows = this.db.prepare(
      `SELECT
          id,
          session_id,
          title,
          status,
          parent_topic_id,
          summary_short,
          summary_long,
          open_loops_json,
          labels_json,
          created_at,
          last_active_at
         FROM topics
         WHERE session_id = ?
         ORDER BY last_active_at DESC`
    ).all(sessionId);
    return rows.map(mapTopicRow);
  }
  async getTopic(topicId) {
    const row = this.db.prepare(
      `SELECT
          id,
          session_id,
          title,
          status,
          parent_topic_id,
          summary_short,
          summary_long,
          open_loops_json,
          labels_json,
          created_at,
          last_active_at
         FROM topics
         WHERE id = ?`
    ).get(topicId);
    return row ? mapTopicRow(row) : null;
  }
  async upsertTopic(record) {
    this.db.prepare(
      `INSERT INTO topics (
          id,
          session_id,
          title,
          status,
          parent_topic_id,
          summary_short,
          summary_long,
          open_loops_json,
          labels_json,
          created_at,
          last_active_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
          session_id = excluded.session_id,
          title = excluded.title,
          status = excluded.status,
          parent_topic_id = excluded.parent_topic_id,
          summary_short = excluded.summary_short,
          summary_long = excluded.summary_long,
          open_loops_json = excluded.open_loops_json,
          labels_json = excluded.labels_json,
          created_at = excluded.created_at,
          last_active_at = excluded.last_active_at`
    ).run(
      record.id,
      record.sessionId,
      record.title,
      record.status,
      record.parentTopicId,
      record.summaryShort,
      record.summaryLong,
      JSON.stringify(record.openLoops),
      JSON.stringify(record.labels),
      record.createdAt,
      record.lastActiveAt
    );
  }
  async upsertTopicMembership(record) {
    this.db.prepare(
      `INSERT INTO topic_membership (
          message_id,
          topic_id,
          score,
          is_primary,
          reason,
          created_at
        ) VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(message_id, topic_id) DO UPDATE SET
          score = excluded.score,
          is_primary = excluded.is_primary,
          reason = excluded.reason,
          created_at = excluded.created_at`
    ).run(
      record.messageId,
      record.topicId,
      record.score,
      record.isPrimary ? 1 : 0,
      record.reason,
      record.createdAt
    );
  }
  async upsertFact(record, tags = []) {
    this.db.exec("BEGIN");
    try {
      this.db.prepare(
        `INSERT INTO facts (
            id,
            scope,
            category,
            key,
            value,
            sensitivity,
            recall_policy,
            confidence,
            source_message_id,
            source_topic_id,
            updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          ON CONFLICT(id) DO UPDATE SET
            scope = excluded.scope,
            category = excluded.category,
            key = excluded.key,
            value = excluded.value,
            sensitivity = excluded.sensitivity,
            recall_policy = excluded.recall_policy,
            confidence = excluded.confidence,
            source_message_id = excluded.source_message_id,
            source_topic_id = excluded.source_topic_id,
            updated_at = excluded.updated_at`
      ).run(
        record.id,
        record.scope,
        record.category,
        record.key,
        record.value,
        record.sensitivity,
        record.recallPolicy,
        record.confidence,
        record.sourceMessageId,
        record.sourceTopicId,
        record.updatedAt
      );
      this.db.prepare(`DELETE FROM fact_tags WHERE fact_id = ?`).run(record.id);
      const insertTag = this.db.prepare(
        `INSERT INTO fact_tags (fact_id, tag) VALUES (?, ?)`
      );
      for (const tag of tags) {
        insertTag.run(record.id, tag);
      }
      this.db.exec("COMMIT");
    } catch (error) {
      this.db.exec("ROLLBACK");
      throw error;
    }
  }
  async listFactsByScope(scope) {
    const rows = this.db.prepare(
      `SELECT
          f.id,
          f.scope,
          f.category,
          f.key,
          f.value,
          f.sensitivity,
          f.recall_policy,
          f.confidence,
          f.source_message_id,
          f.source_topic_id,
          f.updated_at,
          COALESCE(json_group_array(ft.tag) FILTER (WHERE ft.tag IS NOT NULL), '[]') AS tags_json
         FROM facts f
         LEFT JOIN fact_tags ft ON ft.fact_id = f.id
         WHERE f.scope = ?
         GROUP BY
          f.id,
          f.scope,
          f.category,
          f.key,
          f.value,
          f.sensitivity,
          f.recall_policy,
          f.confidence,
          f.source_message_id,
          f.source_topic_id,
          f.updated_at
         ORDER BY f.updated_at DESC`
    ).all(scope);
    return rows.map(mapFactRow);
  }
  async listFactsByTags(tags, recallPolicies = ["always", "topic_bound"]) {
    if (tags.length === 0) {
      return [];
    }
    const tagPlaceholders = tags.map(() => "?").join(", ");
    const recallPolicyPlaceholders = recallPolicies.map(() => "?").join(", ");
    const rows = this.db.prepare(
      `SELECT
          f.id,
          f.scope,
          f.category,
          f.key,
          f.value,
          f.sensitivity,
          f.recall_policy,
          f.confidence,
          f.source_message_id,
          f.source_topic_id,
          f.updated_at,
          COALESCE(json_group_array(DISTINCT ft_all.tag) FILTER (WHERE ft_all.tag IS NOT NULL), '[]') AS tags_json
         FROM facts f
         JOIN fact_tags ft_match ON ft_match.fact_id = f.id
         LEFT JOIN fact_tags ft_all ON ft_all.fact_id = f.id
         WHERE ft_match.tag IN (${tagPlaceholders})
           AND f.recall_policy IN (${recallPolicyPlaceholders})
         GROUP BY
          f.id,
          f.scope,
          f.category,
          f.key,
          f.value,
          f.sensitivity,
          f.recall_policy,
          f.confidence,
          f.source_message_id,
          f.source_topic_id,
          f.updated_at
         ORDER BY f.updated_at DESC`
    ).all(...tags, ...recallPolicies);
    return rows.map(mapFactRow);
  }
  async listRecentMessagesForTopic(topicId, limit) {
    const rows = this.db.prepare(
      `SELECT
          tm.message_id,
          tm.topic_id,
          tm.score,
          tm.is_primary,
          tm.reason,
          tm.created_at,
          m.id,
          m.session_id,
          m.turn_id,
          m.parent_turn_id,
          m.role,
          m.event_type,
          m.text,
          m.ts,
          m.raw_json
         FROM topic_membership tm
         JOIN messages m ON m.id = tm.message_id
         WHERE tm.topic_id = ?
         ORDER BY m.ts DESC
         LIMIT ?`
    ).all(topicId, limit);
    return rows.map(mapRecentTopicMessageRow).reverse();
  }
  async searchTopics(sessionId, query, limit) {
    const normalizedQuery = normalizeSearchQuery(query);
    if (!normalizedQuery) {
      return [];
    }
    const likeValue = `%${escapeLike(normalizedQuery)}%`;
    const rows = this.db.prepare(
      `SELECT
          id,
          session_id,
          title,
          status,
          parent_topic_id,
          summary_short,
          summary_long,
          open_loops_json,
          labels_json,
          created_at,
          last_active_at
         FROM topics
         WHERE session_id = ?
           AND (
             lower(title) LIKE ? ESCAPE '\\'
             OR lower(summary_short) LIKE ? ESCAPE '\\'
             OR lower(summary_long) LIKE ? ESCAPE '\\'
             OR lower(labels_json) LIKE ? ESCAPE '\\'
           )
         ORDER BY last_active_at DESC
         LIMIT ?`
    ).all(sessionId, likeValue, likeValue, likeValue, likeValue, limit);
    return rows.map((row) => mapTopicSearchResult(row, normalizedQuery)).sort((a, b) => b.score - a.score);
  }
  async searchFacts(args) {
    const normalizedQuery = normalizeSearchQuery(args.query);
    if (!normalizedQuery) {
      return [];
    }
    const likeValue = `%${escapeLike(normalizedQuery)}%`;
    const topicScope = args.topicId ? `topic:${args.topicId}` : null;
    const sessionScope = `session:${args.sessionId}`;
    const rows = this.db.prepare(
      `SELECT
          f.id,
          f.scope,
          f.category,
          f.key,
          f.value,
          f.sensitivity,
          f.recall_policy,
          f.confidence,
          f.source_message_id,
          f.source_topic_id,
          f.updated_at,
          COALESCE(json_group_array(DISTINCT ft_all.tag) FILTER (WHERE ft_all.tag IS NOT NULL), '[]') AS tags_json
         FROM facts f
         LEFT JOIN fact_tags ft_match ON ft_match.fact_id = f.id
         LEFT JOIN fact_tags ft_all ON ft_all.fact_id = f.id
         WHERE (
            f.scope IN ('global', 'shared')
            OR f.scope = ?
            OR f.scope = ?
            OR f.source_topic_id IN (
              SELECT id FROM topics WHERE session_id = ?
            )
         )
           AND (
             lower(f.key) LIKE ? ESCAPE '\\'
             OR lower(f.value) LIKE ? ESCAPE '\\'
             OR lower(f.category) LIKE ? ESCAPE '\\'
             OR lower(COALESCE(ft_match.tag, '')) LIKE ? ESCAPE '\\'
           )
         GROUP BY
          f.id,
          f.scope,
          f.category,
          f.key,
          f.value,
          f.sensitivity,
          f.recall_policy,
          f.confidence,
          f.source_message_id,
          f.source_topic_id,
          f.updated_at
         ORDER BY f.updated_at DESC
         LIMIT ?`
    ).all(sessionScope, topicScope, args.sessionId, likeValue, likeValue, likeValue, likeValue, args.limit);
    return rows.map((row) => mapFactSearchResult(row, normalizedQuery)).sort((a, b) => b.score - a.score);
  }
};
async function loadSchemaSql() {
  const candidatePaths = [
    (0, import_node_url.fileURLToPath)(new URL("./schema.sql", importMetaUrl)),
    (0, import_node_url.fileURLToPath)(new URL("../src/schema.sql", importMetaUrl))
  ];
  for (const schemaPath of candidatePaths) {
    try {
      await (0, import_promises.access)(schemaPath);
      return (0, import_promises.readFile)(schemaPath, "utf8");
    } catch {
      continue;
    }
  }
  throw new Error("Unable to locate memory-v2 SQLite schema.sql");
}
function mapSessionStateRow(row) {
  return {
    sessionId: row.session_id,
    activeTopicId: row.active_topic_id,
    lastCompactedAt: row.last_compacted_at,
    lastTurnId: row.last_turn_id,
    updatedAt: row.updated_at
  };
}
function mapTopicRow(row) {
  return {
    id: row.id,
    sessionId: row.session_id,
    title: row.title,
    status: row.status,
    parentTopicId: row.parent_topic_id,
    summaryShort: row.summary_short,
    summaryLong: row.summary_long,
    openLoops: parseJsonArray(row.open_loops_json),
    labels: parseJsonArray(row.labels_json),
    createdAt: row.created_at,
    lastActiveAt: row.last_active_at
  };
}
function mapFactRow(row) {
  return {
    id: row.id,
    scope: row.scope,
    category: row.category,
    key: row.key,
    value: row.value,
    sensitivity: row.sensitivity,
    recallPolicy: row.recall_policy,
    confidence: row.confidence,
    sourceMessageId: row.source_message_id,
    sourceTopicId: row.source_topic_id,
    updatedAt: row.updated_at,
    tags: parseJsonArray(row.tags_json)
  };
}
function mapTopicSearchResult(row, normalizedQuery) {
  const topic = mapTopicRow(row);
  const haystacks = [
    { reason: "title", value: topic.title },
    { reason: "summary_short", value: topic.summaryShort },
    { reason: "summary_long", value: topic.summaryLong },
    { reason: "labels", value: topic.labels.join(" ") }
  ];
  const matchReasons = haystacks.filter((entry) => entry.value.toLowerCase().includes(normalizedQuery)).map((entry) => entry.reason);
  return {
    topic,
    score: scoreTopicSearch(topic, matchReasons),
    matchReasons
  };
}
function mapFactSearchResult(row, normalizedQuery) {
  const fact = mapFactRow(row);
  const haystacks = [
    { reason: "key", value: fact.key },
    { reason: "value", value: fact.value },
    { reason: "category", value: fact.category },
    { reason: "tags", value: fact.tags.join(" ") }
  ];
  const matchReasons = haystacks.filter((entry) => entry.value.toLowerCase().includes(normalizedQuery)).map((entry) => entry.reason);
  return {
    fact,
    score: scoreFactSearch(fact, matchReasons),
    matchReasons
  };
}
function mapRecentTopicMessageRow(row) {
  return {
    membership: {
      messageId: row.message_id,
      topicId: row.topic_id,
      score: row.score,
      isPrimary: row.is_primary === 1,
      reason: row.reason,
      createdAt: row.created_at
    },
    message: {
      id: row.id,
      sessionId: row.session_id,
      turnId: row.turn_id,
      parentTurnId: row.parent_turn_id,
      role: row.role,
      eventType: row.event_type,
      text: row.text,
      ts: row.ts,
      rawJson: row.raw_json
    }
  };
}
function parseJsonArray(value) {
  const parsed = JSON.parse(value);
  if (!Array.isArray(parsed)) {
    return [];
  }
  return parsed.filter((item) => typeof item === "string");
}
function normalizeSearchQuery(query) {
  return query.trim().toLowerCase();
}
function escapeLike(value) {
  return value.replace(/[\\%_]/g, "\\$&");
}
function scoreTopicSearch(topic, matchReasons) {
  let score = 0;
  for (const reason of matchReasons) {
    if (reason === "title") {
      score += 5;
    } else if (reason === "labels") {
      score += 4;
    } else if (reason === "summary_short") {
      score += 3;
    } else if (reason === "summary_long") {
      score += 2;
    }
  }
  if (topic.status === "active") {
    score += 1;
  }
  return score;
}
function scoreFactSearch(fact, matchReasons) {
  let score = 0;
  for (const reason of matchReasons) {
    if (reason === "key") {
      score += 5;
    } else if (reason === "tags") {
      score += 4;
    } else if (reason === "value") {
      score += 3;
    } else if (reason === "category") {
      score += 1;
    }
  }
  if (fact.recallPolicy === "always") {
    score += 1;
  }
  return score;
}

// ../../packages/summary-refresher/src/index.ts
var SummaryRefresher = class {
  constructor(_config) {
    this._config = _config;
  }
  refresh(input) {
    const latestMessage = input.recentMessages.at(-1)?.message.text ?? input.topic.summaryShort;
    const factFragments = input.facts.slice(0, 2).map((fact) => `${fact.key}=${fact.value}`).join("; ");
    const loopFragment = input.topic.openLoops.length > 0 ? ` Open loops: ${input.topic.openLoops.slice(-2).join(" | ")}.` : "";
    const summaryShort = truncate(
      [input.topic.title, latestMessage, factFragments].filter(Boolean).join(" | "),
      220
    );
    const summaryLong = truncate(
      `${summaryShort}${loopFragment}`,
      600
    );
    return {
      summaryShort,
      summaryLong
    };
  }
};
function truncate(value, max) {
  return value.length <= max ? value : `${value.slice(0, max)}...`;
}

// ../../packages/topic-router/src/index.ts
var TopicRouter = class {
  constructor(config) {
    this.config = config;
  }
  route(input) {
    const normalizedText = normalize(input.text);
    const hasShiftSignal = containsShiftSignal(normalizedText);
    const hasExplicitNewTopicSignal = containsExplicitNewTopicSignal(normalizedText);
    if (!normalizedText) {
      if (input.activeTopicId) {
        return {
          action: "continue",
          topicId: input.activeTopicId,
          reason: "empty-message-falls-back-to-active-topic"
        };
      }
      return {
        action: "spawn",
        topicId: null,
        reason: "empty-message-without-active-topic"
      };
    }
    const activeTopic = input.recentTopics.find(
      (topic) => topic.id === input.activeTopicId
    );
    if (hasExplicitNewTopicSignal) {
      return {
        action: "spawn",
        topicId: null,
        reason: "explicit-new-topic-signal"
      };
    }
    if (activeTopic && !shouldBreakFromActive(activeTopic, normalizedText, hasShiftSignal) && scoreTopicMatch(activeTopic, normalizedText, {
      rank: 0,
      isActive: true
    }) >= this.getContinueThreshold()) {
      return {
        action: "continue",
        topicId: activeTopic.id,
        reason: "matched-active-topic"
      };
    }
    const matchedExisting = findBestTopicMatch(
      input.recentTopics,
      normalizedText,
      this.getSwitchThreshold(),
      input.activeTopicId
    );
    if (matchedExisting) {
      return {
        action: "switch",
        topicId: matchedExisting.id,
        reason: "matched-existing-topic"
      };
    }
    return {
      action: "spawn",
      topicId: null,
      reason: "no-topic-match-above-threshold"
    };
  }
  getSwitchThreshold() {
    return this.config.topicRouting?.switchTopicThreshold ?? 0.68;
  }
  getContinueThreshold() {
    const configured = this.config.topicRouting?.newTopicThreshold;
    if (typeof configured === "number") {
      return configured;
    }
    return Math.max(0.22, this.getSwitchThreshold() * 0.55);
  }
};
function findBestTopicMatch(topics, normalizedText, threshold, activeTopicId) {
  let bestTopic = null;
  let bestScore = 0;
  let rank = 0;
  for (const topic of topics) {
    if (topic.id === activeTopicId) {
      continue;
    }
    const score = scoreTopicMatch(topic, normalizedText, {
      rank,
      isActive: false
    });
    if (score >= threshold && score > bestScore) {
      bestScore = score;
      bestTopic = topic;
    }
    rank += 1;
  }
  return bestTopic;
}
function scoreTopicMatch(topic, normalizedText, context) {
  const textTokens = tokenizeMeaningful(normalizedText);
  const candidateTexts = [
    topic.title,
    topic.summaryShort,
    topic.summaryLong,
    ...topic.openLoops
  ].map(normalize);
  const candidateTokens = tokenizeMeaningful(
    [topic.title, topic.summaryShort, topic.summaryLong, ...topic.labels, ...topic.openLoops].map(normalize).join(" ")
  );
  const labelTokens = tokenizeMeaningful(topic.labels.join(" "));
  let bestPhraseScore = 0;
  for (const candidate of candidateTexts) {
    if (!candidate) {
      continue;
    }
    if (candidate.includes(normalizedText) || normalizedText.includes(candidate)) {
      bestPhraseScore = Math.max(
        bestPhraseScore,
        overlapScore(candidate, normalizedText)
      );
    }
  }
  const tokenIntersection = countIntersection(candidateTokens, textTokens);
  const labelIntersection = countIntersection(labelTokens, textTokens);
  const tokenScore = tokenIntersection === 0 ? 0 : tokenIntersection / Math.max(1, Math.min(candidateTokens.size, textTokens.size));
  const labelScore = labelIntersection === 0 ? 0 : labelIntersection / Math.max(1, Math.min(labelTokens.size, textTokens.size));
  const recencyBonus = context.rank === 0 ? 0.12 : context.rank === 1 ? 0.06 : 0;
  const activeBonus = context.isActive ? 0.18 : 0;
  const loopBonus = topic.openLoops.length > 0 && /继续|待办|下一步|todo|follow up/i.test(normalizedText) ? 0.08 : 0;
  return clamp01(
    bestPhraseScore * 0.5 + tokenScore * 0.6 + labelScore * 0.45 + recencyBonus + activeBonus + loopBonus
  );
}
function shouldBreakFromActive(topic, normalizedText, hasShiftSignal) {
  if (!hasShiftSignal) {
    return false;
  }
  const activeTokens = tokenizeMeaningful(
    [topic.title, topic.summaryShort, ...topic.labels].map(normalize).join(" ")
  );
  const textTokens = tokenizeMeaningful(normalizedText);
  const overlap = countIntersection(activeTokens, textTokens);
  return overlap <= 1;
}
function overlapScore(left, right) {
  const smaller = Math.min(left.length, right.length);
  const larger = Math.max(left.length, right.length);
  return smaller / larger;
}
function tokenizeMeaningful(value) {
  return new Set(
    value.split(/[^a-z0-9_\u4e00-\u9fff]+/i).map((token) => token.trim()).filter((token) => token.length >= 2).filter((token) => !STOP_TOKENS.has(token))
  );
}
function normalize(value) {
  return value.trim().toLowerCase();
}
function containsShiftSignal(value) {
  return [
    "\u5207\u5230",
    "\u5207\u56DE",
    "\u8F6C\u5230",
    "\u6362\u5230",
    "\u6362\u4E2A\u8BDD\u9898",
    "\u6362\u4E00\u4E2A\u8BDD\u9898",
    "\u804A\u804A",
    "\u56DE\u5230",
    "\u91CD\u65B0\u804A",
    "\u6362\u4E2A\u4E3B\u9898",
    "\u5207\u6362\u5230",
    "switch to",
    "move to",
    "back to",
    "new topic"
  ].some((marker) => value.includes(marker));
}
function containsExplicitNewTopicSignal(value) {
  return [
    "\u65B0\u7684 topic",
    "\u65B0\u7684topic",
    "\u65B0 topic",
    "\u65B0topic",
    "\u8FD9\u662F\u4E00\u4E2A\u65B0\u7684",
    "\u8FD9\u662F\u65B0\u7684\u8BDD\u9898",
    "\u8FD9\u662F\u4E00\u4E2A\u65B0\u7684\u8BDD\u9898",
    "\u5F00\u542F\u4E00\u4E2A\u65B0\u8BDD\u9898",
    "\u5F00\u59CB\u4E00\u4E2A\u65B0\u8BDD\u9898",
    "\u5F00\u4E00\u4E2A\u65B0\u8BDD\u9898",
    "\u6362\u4E2A\u65B0\u8BDD\u9898",
    "\u6211\u4EEC\u5F00\u542F\u4E00\u4E2A\u65B0\u8BDD\u9898",
    "\u73B0\u5728\u5F00\u59CB\u4E00\u4E2A\u65B0\u8BDD\u9898",
    "\u4ECE\u8FD9\u9875\u91CD\u65B0\u5F00\u59CB",
    "\u91CD\u65B0\u5F00\u59CB\u4E00\u4E2A\u8BDD\u9898",
    "let's start a new topic",
    "start a new topic",
    "this is a new topic"
  ].some((marker) => value.includes(marker));
}
function countIntersection(left, right) {
  return [...left].filter((token) => right.has(token)).length;
}
function clamp01(value) {
  return Math.max(0, Math.min(1, value));
}
var STOP_TOKENS = /* @__PURE__ */ new Set([
  "\u5F53\u524D",
  "\u8FD9\u4E2A",
  "\u6211\u4EEC",
  "\u7EE7\u7EED",
  "\u8BA8\u8BBA",
  "\u5904\u7406",
  "\u4E00\u4E0B",
  "\u4E00\u4E2A",
  "topic",
  "topics"
]);

// ../bamdra-memory-context-engine/src/index.ts
var import_node_crypto = require("crypto");
var import_node_os = require("os");
var import_node_path2 = require("node:path");
var DEFAULT_DB_PATH = (0, import_node_path2.join)(
  (0, import_node_os.homedir)(),
  ".openclaw",
  "memory",
  process.env.OPENCLAW_BAMDRA_MEMORY_DB_BASENAME || "main.sqlite"
);
function logMemoryEvent(event, details = {}) {
  try {
    console.info("[bamdra-openclaw-memory]", event, JSON.stringify(details));
  } catch {
    console.info("[bamdra-openclaw-memory]", event);
  }
}
function createContextEngineMemoryV2Plugin(inputConfig, api) {
  const config = normalizeMemoryConfig(inputConfig);
  const store = new MemorySqliteStore({
    path: config.store.path
  });
  let cache = new InMemoryCacheStore(config.cache);
  const router = new TopicRouter(config);
  const assembler = new ContextAssembler(config);
  const factExtractor = new FactExtractor(config);
  const summaryRefresher = new SummaryRefresher(config);
  let migrationsApplied = false;
  let migrationsPromise = null;
  async function ensureMigrations() {
    if (migrationsApplied) return;
    if (migrationsPromise) return migrationsPromise;
    migrationsPromise = store.applyMigrations().then(() => {
      migrationsApplied = true;
    });
    return migrationsPromise;
  }
  let hooksRegistered = false;
  const plugin = {
    name: "bamdra-openclaw-memory",
    type: "context-engine",
    slot: "memory",
    capabilities: ["memory"],
    config,
    registerHooks(hostApi) {
      if (hooksRegistered) {
        return;
      }
      const registerHook = getInternalHookRegistrar(hostApi);
      const registerTypedHook = getTypedHookRegistrar(hostApi);
      if (registerHook) {
        registerHook(
          ["message:received", "message:preprocessed"],
          async (event) => {
            const sessionId = getSessionIdFromHookContext(event);
            const text = getTextFromHookContext(event);
            logMemoryEvent("hook-ingest-received", {
              hasSessionId: Boolean(sessionId),
              textPreview: typeof text === "string" ? text.slice(0, 80) : null
            });
            if (!sessionId || !text) {
              return;
            }
            const result = await plugin.routeAndTrack(sessionId, text);
            logMemoryEvent("hook-ingest-tracked", {
              sessionId,
              action: result.decision.action,
              reason: result.decision.reason,
              topicId: result.topicId,
              messageId: result.messageId
            });
          },
          {
            name: "bamdra-memory-ingest",
            description: "Track inbound conversation turns into bamdra memory topics and facts"
          }
        );
      } else {
        logMemoryEvent("register-hooks-skipped", { reason: "registerHook unavailable" });
      }
      if (registerTypedHook) {
        registerTypedHook("before_prompt_build", async (event, hookContext) => {
          const sessionId = getSessionIdFromHookContext(hookContext);
          const text = getTextFromHookContext(event);
          logMemoryEvent("hook-assemble-received", {
            hasSessionId: Boolean(sessionId),
            hasText: Boolean(text)
          });
          if (!sessionId) {
            return;
          }
          if (text) {
            const result = await plugin.routeAndTrack(sessionId, text);
            logMemoryEvent("hook-before-prompt-tracked", {
              sessionId,
              action: result.decision.action,
              reason: result.decision.reason,
              topicId: result.topicId,
              messageId: result.messageId
            });
          }
          const assembled = await plugin.assembleContext(sessionId);
          logMemoryEvent("hook-assemble-complete", {
            sessionId,
            topicId: assembled.topicId,
            sections: assembled.sections.length
          });
          return buildBeforePromptBuildResult(assembled);
        });
      } else {
        logMemoryEvent("register-typed-hooks-skipped", { reason: "typed hook registrar unavailable" });
      }
      if (!registerHook && !registerTypedHook) {
        return;
      }
      logMemoryEvent("register-hooks-complete", {
        internalHooks: registerHook ? ["message:received", "message:preprocessed"] : [],
        typedHooks: registerTypedHook ? ["before_prompt_build"] : []
      });
      hooksRegistered = true;
    },
    async setup() {
      await ensureMigrations();
    },
    async close() {
      await store.close();
    },
    async listTopics(sessionId) {
      await ensureMigrations();
      const sessionState = await resolveSessionState(store, cache, sessionId);
      const topics = await store.listTopics(sessionId);
      return topics.map((topic) => ({
        ...topic,
        isActive: sessionState?.activeTopicId === topic.id
      }));
    },
    async switchTopic(sessionId, topicId) {
      await ensureMigrations();
      const topic = await store.getTopic(topicId);
      if (!topic || topic.sessionId !== sessionId) {
        throw new Error(`Topic ${topicId} does not belong to session ${sessionId}`);
      }
      const now = (/* @__PURE__ */ new Date()).toISOString();
      await cache.setSessionState(sessionId, {
        activeTopicId: topicId,
        updatedAt: now
      });
      const previousState = await store.getSessionState(sessionId);
      const updatedTopic = {
        ...topic,
        status: "active",
        lastActiveAt: now
      };
      await store.upsertTopic(updatedTopic);
      await store.upsertSessionState({
        sessionId,
        activeTopicId: topicId,
        lastCompactedAt: previousState?.lastCompactedAt ?? null,
        lastTurnId: previousState?.lastTurnId ?? null,
        updatedAt: now
      });
      logMemoryEvent("switch-topic", { sessionId, topicId, title: updatedTopic.title });
      return updatedTopic;
    },
    async saveFact(args) {
      await ensureMigrations();
      const now = (/* @__PURE__ */ new Date()).toISOString();
      const sessionState = await resolveSessionState(store, cache, args.sessionId);
      const resolvedTopicId = args.topicId ?? sessionState?.activeTopicId ?? null;
      const resolvedTopic = resolvedTopicId != null ? await store.getTopic(resolvedTopicId) : null;
      const normalizedScope = normalizeFactScope(args.scope, args.sessionId);
      const scope = normalizedScope ?? (resolvedTopic != null ? `topic:${resolvedTopic.id}` : "shared");
      const tags = dedupeTextItems([
        ...resolvedTopic?.labels ?? [],
        ...args.tags ?? [],
        args.category ?? "background"
      ]);
      await store.upsertFact(
        {
          id: createFactId(scope, args.key),
          scope,
          category: args.category ?? "background",
          key: args.key,
          value: args.value,
          sensitivity: args.sensitivity ?? "normal",
          recallPolicy: args.recallPolicy ?? (resolvedTopic ? "topic_bound" : "always"),
          confidence: 1,
          sourceMessageId: null,
          sourceTopicId: resolvedTopic?.id ?? null,
          updatedAt: now
        },
        tags
      );
      if (resolvedTopic) {
        await refreshTopicSummary(store, summaryRefresher, config, resolvedTopic.id, now);
      }
      logMemoryEvent("save-fact", {
        sessionId: args.sessionId,
        topicId: resolvedTopic?.id ?? null,
        key: args.key,
        scope,
        tags
      });
      return {
        topicId: resolvedTopic?.id ?? null,
        tags
      };
    },
    async compactTopic(args) {
      await ensureMigrations();
      const now = (/* @__PURE__ */ new Date()).toISOString();
      const sessionState = await resolveSessionState(store, cache, args.sessionId);
      const topicId = args.topicId ?? sessionState?.activeTopicId ?? null;
      if (!topicId) {
        throw new Error(`Session ${args.sessionId} does not have an active topic`);
      }
      const topic = await store.getTopic(topicId);
      if (!topic || topic.sessionId !== args.sessionId) {
        throw new Error(`Topic ${topicId} does not belong to session ${args.sessionId}`);
      }
      const refreshedTopic = await refreshTopicSummary(
        store,
        summaryRefresher,
        config,
        topic.id,
        now
      );
      await store.upsertSessionState({
        sessionId: args.sessionId,
        activeTopicId: sessionState?.activeTopicId ?? topic.id,
        lastCompactedAt: now,
        lastTurnId: sessionState?.lastTurnId ?? null,
        updatedAt: now
      });
      await cache.setSessionState(args.sessionId, {
        activeTopicId: sessionState?.activeTopicId ?? topic.id,
        updatedAt: now
      });
      logMemoryEvent("compact-topic", {
        sessionId: args.sessionId,
        topicId: refreshedTopic.id,
        title: refreshedTopic.title
      });
      return refreshedTopic;
    },
    async searchMemory(args) {
      await ensureMigrations();
      const sessionState = await resolveSessionState(store, cache, args.sessionId);
      const limit = args.limit ?? 5;
      const resolvedTopicId = args.topicId ?? sessionState?.activeTopicId ?? null;
      const [topics, facts] = await Promise.all([
        store.searchTopics(args.sessionId, args.query, limit),
        store.searchFacts({
          sessionId: args.sessionId,
          query: args.query,
          topicId: resolvedTopicId,
          limit
        })
      ]);
      return {
        sessionId: args.sessionId,
        query: args.query,
        topics,
        facts
      };
    },
    async routeTopic(sessionId, text) {
      await ensureMigrations();
      const persistedState = await resolveSessionState(store, cache, sessionId);
      const recentTopics = await store.listTopics(sessionId);
      return router.route({
        sessionId,
        text,
        activeTopicId: persistedState?.activeTopicId ?? null,
        recentTopics
      });
    },
    async assembleContext(sessionId) {
      await ensureMigrations();
      const sessionState = await resolveSessionState(store, cache, sessionId);
      const topic = sessionState?.activeTopicId != null ? await store.getTopic(sessionState.activeTopicId) : null;
      const recentMessages = topic != null ? await store.listRecentMessagesForTopic(
        topic.id,
        config.contextAssembly?.recentTurns ?? 6
      ) : [];
      const alwaysFacts = await store.listFactsByScope("global");
      const sharedFacts = await store.listFactsByScope("shared");
      const sessionFacts = await store.listFactsByScope(`session:${sessionId}`);
      const scopedTopicFacts = topic != null ? await store.listFactsByScope(`topic:${topic.id}`) : [];
      const labelFacts = topic != null ? await store.listFactsByTags(topic.labels, ["always", "topic_bound"]) : [];
      return assembler.assemble({
        sessionId,
        topic,
        recentMessages,
        alwaysFacts: dedupeFacts([...alwaysFacts, ...sharedFacts, ...sessionFacts]),
        topicFacts: dedupeFacts([...scopedTopicFacts, ...labelFacts])
      });
    },
    async routeAndTrack(sessionId, text) {
      await ensureMigrations();
      const cachedState = await cache.getSessionState(sessionId);
      const persistedState = cachedState ? mapCachedStateToSessionState(sessionId, cachedState) : await store.getSessionState(sessionId);
      const recentTopics = await store.listTopics(sessionId);
      const decision = router.route({
        sessionId,
        text,
        activeTopicId: persistedState?.activeTopicId ?? null,
        recentTopics
      });
      const now = (/* @__PURE__ */ new Date()).toISOString();
      const topicId = decision.action === "spawn" ? createTopicId(sessionId, text) : decision.topicId;
      const messageId = (0, import_node_crypto.randomUUID)();
      const topicRecord = decision.action === "spawn" ? createSpawnedTopic(sessionId, topicId, text, now, persistedState?.activeTopicId ?? null) : await store.getTopic(topicId);
      if (!topicRecord) {
        throw new Error(`Unable to resolve topic ${topicId} after routing`);
      }
      if (decision.action === "spawn") {
        await store.upsertTopic(topicRecord);
      } else {
        await store.upsertTopic({
          ...topicRecord,
          status: "active",
          openLoops: mergeOpenLoops(topicRecord.openLoops, text),
          lastActiveAt: now
        });
      }
      const messageRecord = {
        id: messageId,
        sessionId,
        turnId: messageId,
        parentTurnId: persistedState?.lastTurnId ?? null,
        role: "user",
        eventType: "message",
        text,
        ts: now,
        rawJson: JSON.stringify({ role: "user", text })
      };
      await store.upsertMessage(messageRecord);
      const membership = {
        messageId,
        topicId,
        score: 1,
        isPrimary: true,
        reason: decision.reason,
        createdAt: now
      };
      await store.upsertTopicMembership(membership);
      const extractedFacts = factExtractor.extract({
        sessionId,
        text,
        topic: decision.action === "spawn" ? topicRecord : {
          ...topicRecord,
          openLoops: mergeOpenLoops(topicRecord.openLoops, text),
          lastActiveAt: now
        }
      });
      for (const candidate of extractedFacts) {
        await store.upsertFact(
          mapExtractedFactCandidate(candidate, {
            sourceMessageId: messageId,
            sourceTopicId: topicId,
            updatedAt: now
          }),
          candidate.tags
        );
      }
      await refreshTopicSummary(store, summaryRefresher, config, topicId, now);
      await cache.setSessionState(sessionId, {
        activeTopicId: topicId,
        updatedAt: now
      });
      await store.upsertSessionState({
        sessionId,
        activeTopicId: topicId,
        lastCompactedAt: persistedState?.lastCompactedAt ?? null,
        lastTurnId: messageId,
        updatedAt: now
      });
      logMemoryEvent("route-and-track", {
        sessionId,
        action: decision.action,
        reason: decision.reason,
        topicId,
        extractedFactCount: extractedFacts.length
      });
      return {
        decision,
        topicId,
        messageId
      };
    }
  };
  plugin.registerHooks(api);
  return plugin;
}
async function resolveSessionState(store, cache, sessionId) {
  const cachedState = await cache.getSessionState(sessionId);
  return cachedState ? mapCachedStateToSessionState(sessionId, cachedState) : store.getSessionState(sessionId);
}
function mapCachedStateToSessionState(sessionId, cached) {
  return {
    sessionId,
    activeTopicId: cached.activeTopicId,
    lastCompactedAt: null,
    lastTurnId: null,
    updatedAt: cached.updatedAt
  };
}
function createTopicId(sessionId, text) {
  const digest = (0, import_node_crypto.createHash)("sha1").update(`${sessionId}:${text}:${Date.now()}`).digest("hex").slice(0, 12);
  return `topic-${digest}`;
}
function createFactId(scope, key) {
  const digest = (0, import_node_crypto.createHash)("sha1").update(`${scope}:${key}`).digest("hex").slice(0, 16);
  return `fact-${digest}`;
}
function normalizeFactScope(scope, sessionId) {
  if (typeof scope !== "string") {
    return null;
  }
  const normalized = scope.trim().toLowerCase();
  if (!normalized) {
    return null;
  }
  if (normalized === "session") {
    return `session:${sessionId}`;
  }
  return normalized;
}
function createSpawnedTopic(sessionId, topicId, text, now, parentTopicId) {
  return {
    id: topicId,
    sessionId,
    title: deriveTopicTitle(text),
    status: "active",
    parentTopicId,
    summaryShort: text,
    summaryLong: "",
    openLoops: mergeOpenLoops([], text),
    labels: deriveTopicLabels(text),
    createdAt: now,
    lastActiveAt: now
  };
}
function deriveTopicTitle(text) {
  const compact = text.trim().replace(/\s+/g, " ");
  return compact.length <= 32 ? compact : `${compact.slice(0, 32)}...`;
}
function deriveTopicLabels(text) {
  return dedupeTextItems(
    text.toLowerCase().split(/[^a-z0-9_\u4e00-\u9fff]+/i).map((token) => token.trim()).filter((token) => token.length >= 2).slice(0, 8)
  );
}
function mergeOpenLoops(existing, text) {
  const next = [...existing];
  if (looksLikeOpenLoop(text)) {
    next.push(text.trim());
  }
  return dedupeTextItems(next).slice(-8);
}
function looksLikeOpenLoop(text) {
  const normalized = text.toLowerCase();
  return [
    "todo",
    "\u5F85\u529E",
    "\u9700\u8981",
    "\u7EE7\u7EED",
    "\u540E\u9762",
    "remember",
    "follow up",
    "\u4E0B\u4E00\u6B65"
  ].some((marker) => normalized.includes(marker));
}
function dedupeFacts(facts) {
  const seen = /* @__PURE__ */ new Set();
  return facts.filter((fact) => {
    if (seen.has(fact.id)) {
      return false;
    }
    seen.add(fact.id);
    return true;
  });
}
function dedupeTextItems(values) {
  const seen = /* @__PURE__ */ new Set();
  const result = [];
  for (const value of values) {
    const normalized = value.trim();
    if (!normalized) {
      continue;
    }
    const key = normalized.toLowerCase();
    if (seen.has(key)) {
      continue;
    }
    seen.add(key);
    result.push(normalized);
  }
  return result;
}
function mapExtractedFactCandidate(candidate, meta) {
  return {
    id: (0, import_node_crypto.createHash)("sha1").update(`${candidate.scope}:${candidate.key}:${candidate.value}`).digest("hex").slice(0, 24),
    scope: candidate.scope,
    category: candidate.category,
    key: candidate.key,
    value: candidate.value,
    sensitivity: candidate.sensitivity,
    recallPolicy: candidate.recallPolicy,
    confidence: candidate.confidence,
    sourceMessageId: meta.sourceMessageId,
    sourceTopicId: meta.sourceTopicId,
    updatedAt: meta.updatedAt
  };
}
async function refreshTopicSummary(store, summaryRefresher, config, topicId, now) {
  const topic = await store.getTopic(topicId);
  if (!topic) {
    throw new Error(`Unable to refresh summary for missing topic ${topicId}`);
  }
  const recentMessages = await store.listRecentMessagesForTopic(
    topicId,
    config.contextAssembly?.recentTurns ?? 6
  );
  const refreshedFacts = dedupeFacts([
    ...await store.listFactsByScope(`topic:${topicId}`),
    ...await store.listFactsByTags(topic.labels, ["always", "topic_bound"])
  ]);
  const refreshedSummary = summaryRefresher.refresh({
    topic,
    recentMessages,
    facts: refreshedFacts
  });
  const updatedTopic = {
    ...topic,
    ...refreshedSummary,
    lastActiveAt: now
  };
  await store.upsertTopic(updatedTopic);
  return updatedTopic;
}
function normalizeMemoryConfig(inputConfig) {
  return {
    enabled: inputConfig?.enabled ?? true,
    store: {
      provider: "sqlite",
      path: inputConfig?.store?.path || process.env.OPENCLAW_BAMDRA_MEMORY_DB_PATH || process.env.OPENCLAW_MEMORY_DB_PATH || DEFAULT_DB_PATH
    },
    cache: {
      provider: "memory",
      maxSessions: inputConfig?.cache?.maxSessions ?? 128,
      maxTopicsPerSession: inputConfig?.cache?.maxTopicsPerSession ?? 64,
      maxFacts: inputConfig?.cache?.maxFacts ?? 2048
    },
    topicRouting: {
      maxRecentTopics: inputConfig?.topicRouting?.maxRecentTopics ?? 12,
      newTopicThreshold: inputConfig?.topicRouting?.newTopicThreshold ?? 0.28,
      switchTopicThreshold: inputConfig?.topicRouting?.switchTopicThreshold ?? 0.55
    },
    contextAssembly: {
      recentTurns: inputConfig?.contextAssembly?.recentTurns ?? 6,
      includeTopicShortSummary: inputConfig?.contextAssembly?.includeTopicShortSummary ?? true,
      includeOpenLoops: inputConfig?.contextAssembly?.includeOpenLoops ?? true,
      alwaysFactLimit: inputConfig?.contextAssembly?.alwaysFactLimit ?? 12,
      topicFactLimit: inputConfig?.contextAssembly?.topicFactLimit ?? 16
    }
  };
}
function getInternalHookRegistrar(api) {
  if (!api || typeof api !== "object") {
    return null;
  }
  const registrar = api.registerHook;
  if (typeof registrar !== "function") {
    return null;
  }
  return registrar.bind(api);
}
function getTypedHookRegistrar(api) {
  if (!api || typeof api !== "object") {
    return null;
  }
  const registrar = api.on;
  if (typeof registrar !== "function") {
    return null;
  }
  return registrar.bind(api);
}
function getSessionIdFromHookContext(context) {
  if (!context || typeof context !== "object") {
    return null;
  }
  const candidate = context;
  const sessionId = candidate.sessionKey ?? candidate.sessionId ?? candidate.session?.id ?? candidate.conversation?.id ?? candidate.metadata?.sessionId ?? candidate.context?.sessionId ?? candidate.input?.sessionId ?? candidate.input?.session?.id;
  return typeof sessionId === "string" && sessionId.trim() ? sessionId : null;
}
function getTextFromHookContext(context) {
  if (!context || typeof context !== "object") {
    return null;
  }
  const candidate = context;
  const directText = normalizeHookText(
    candidate.bodyForAgent ?? candidate.body ?? candidate.prompt ?? candidate.text ?? candidate.context?.bodyForAgent ?? candidate.context?.body ?? candidate.context?.text ?? candidate.context?.content
  );
  if (directText) {
    return directText;
  }
  const messageText = normalizeHookText(candidate.message?.text ?? candidate.message?.content);
  if (messageText) {
    return messageText;
  }
  const inputText = extractTextFromInput(candidate.input);
  if (inputText) {
    return inputText;
  }
  const lastUserMessage = [...candidate.messages ?? []].reverse().find((message) => (message.role ?? "user") === "user");
  return normalizeHookText(lastUserMessage?.text ?? lastUserMessage?.content);
}
function extractTextFromInput(input) {
  if (typeof input === "string") {
    return normalizeHookText(input);
  }
  if (!input || typeof input !== "object") {
    return null;
  }
  const candidate = input;
  const directText = normalizeHookText(candidate.text ?? candidate.content);
  if (directText) {
    return directText;
  }
  const messageText = normalizeHookText(candidate.message?.text ?? candidate.message?.content);
  if (messageText) {
    return messageText;
  }
  const lastUserMessage = [...candidate.messages ?? []].reverse().find((message) => (message.role ?? "user") === "user");
  return normalizeHookText(lastUserMessage?.text ?? lastUserMessage?.content);
}
function normalizeHookText(value) {
  if (typeof value !== "string") {
    return null;
  }
  const normalized = value.trim();
  return normalized ? normalized : null;
}
function buildBeforePromptBuildResult(assembled) {
  const text = assembled.text.trim();
  if (!text) {
    return void 0;
  }
  return {
    prependSystemContext: text
  };
}

// src/index.ts
var import_node_fs2 = require("node:fs");
var import_node_os2 = require("os");
var import_node_path3 = require("node:path");
var PLUGIN_ID = "bamdra-openclaw-memory";
var ENGINE_GLOBAL_KEY = "__OPENCLAW_BAMDRA_MEMORY_CONTEXT_ENGINE__";
var TOOLS_REGISTERED_KEY = /* @__PURE__ */ Symbol.for("bamdra-openclaw-memory.tools-registered");
var ENGINE_REGISTERED_KEY = /* @__PURE__ */ Symbol.for("bamdra-openclaw-memory.context-engine-registered");
var BOOTSTRAP_STARTED_KEY = /* @__PURE__ */ Symbol.for("bamdra-openclaw-memory.host-bootstrap-started");
var SKILL_ID = "bamdra-memory-operator";
var REQUIRED_TOOL_NAMES = [
  "memory_list_topics",
  "memory_switch_topic",
  "memory_save_fact",
  "memory_compact_topic",
  "memory_search"
];
function logUnifiedMemoryEvent(event, details = {}) {
  try {
    console.info("[bamdra-openclaw-memory]", event, JSON.stringify(details));
  } catch {
    console.info("[bamdra-openclaw-memory]", event);
  }
}
function register(api) {
  initializeUnifiedPlugin(api, "register");
}
async function activate(api) {
  initializeUnifiedPlugin(api, "activate");
}
function initializeUnifiedPlugin(api, phase) {
  logUnifiedMemoryEvent(`${phase}-plugin`, { id: PLUGIN_ID });
  if (!api[BOOTSTRAP_STARTED_KEY]) {
    api[BOOTSTRAP_STARTED_KEY] = true;
    queueMicrotask(() => {
      try {
        bootstrapOpenClawHost();
      } catch (error) {
        logUnifiedMemoryEvent("host-bootstrap-failed", {
          message: error instanceof Error ? error.message : String(error)
        });
      }
    });
  }
  const engine = brandContextEngine(createContextEngineMemoryV2Plugin(api.pluginConfig ?? api.config, api));
  exposeContextEngine(engine);
  engine.registerHooks(api);
  if (!api[TOOLS_REGISTERED_KEY] && typeof api.registerTool === "function") {
    registerUnifiedTools(api, engine);
    api[TOOLS_REGISTERED_KEY] = true;
    logUnifiedMemoryEvent("tools-ready", { id: PLUGIN_ID });
  }
  if (api[ENGINE_REGISTERED_KEY]) {
    return;
  }
  api.registerContextEngine(PLUGIN_ID, async (config) => {
    const configured = brandContextEngine(createContextEngineMemoryV2Plugin(config, api));
    exposeContextEngine(configured);
    configured.registerHooks(api);
    await configured.setup();
    logUnifiedMemoryEvent("context-engine-ready", {
      id: PLUGIN_ID,
      dbPath: configured.config.store.path
    });
    return configured;
  });
  api[ENGINE_REGISTERED_KEY] = true;
}
function brandContextEngine(engine) {
  engine.name = PLUGIN_ID;
  return engine;
}
function exposeContextEngine(engine) {
  globalThis[ENGINE_GLOBAL_KEY] = engine;
  process.env.OPENCLAW_BAMDRA_MEMORY_DB_PATH = engine.config.store.path;
}
function registerUnifiedTools(api, engine) {
  const definitions = [
    createToolDefinitions({
      name: "memory_list_topics",
      description: "List known topics for a session",
      parameters: {
        type: "object",
        additionalProperties: false,
        required: ["sessionId"],
        properties: {
          sessionId: { type: "string" }
        }
      },
      async execute(params) {
        return engine.listTopics(params.sessionId);
      }
    }),
    createToolDefinitions({
      name: "memory_switch_topic",
      description: "Switch the active topic for a session",
      parameters: {
        type: "object",
        additionalProperties: false,
        required: ["sessionId", "topicId"],
        properties: {
          sessionId: { type: "string" },
          topicId: { type: "string" }
        }
      },
      async execute(params) {
        return engine.switchTopic(params.sessionId, params.topicId);
      }
    }),
    createToolDefinitions({
      name: "memory_save_fact",
      description: "Persist a pinned memory fact for the current or selected topic",
      parameters: {
        type: "object",
        additionalProperties: false,
        required: ["sessionId", "key", "value"],
        properties: {
          sessionId: { type: "string" },
          key: { type: "string" },
          value: { type: "string" },
          category: { type: "string" },
          sensitivity: { type: "string" },
          recallPolicy: { type: "string" },
          scope: { type: "string" },
          topicId: { type: ["string", "null"] },
          tags: {
            type: "array",
            items: { type: "string" }
          }
        }
      },
      async execute(params) {
        return engine.saveFact(params);
      }
    }),
    createToolDefinitions({
      name: "memory_compact_topic",
      description: "Force refresh the summary for the current or selected topic",
      parameters: {
        type: "object",
        additionalProperties: false,
        required: ["sessionId"],
        properties: {
          sessionId: { type: "string" },
          topicId: { type: ["string", "null"] }
        }
      },
      async execute(params) {
        return engine.compactTopic(params);
      }
    }),
    createToolDefinitions({
      name: "memory_search",
      description: "Search topics and durable facts for a session",
      parameters: {
        type: "object",
        additionalProperties: false,
        required: ["sessionId", "query"],
        properties: {
          sessionId: { type: "string" },
          query: { type: "string" },
          topicId: { type: ["string", "null"] },
          limit: { type: "integer", minimum: 1, maximum: 20 }
        }
      },
      async execute(params) {
        return engine.searchMemory(params);
      }
    })
  ];
  for (const group of definitions) {
    for (const definition of group) {
      api.registerTool?.(definition);
      logUnifiedMemoryEvent("tool-registered", { name: definition.name });
    }
  }
}
function createToolDefinitions(definition) {
  return [{
    name: definition.name,
    description: definition.description,
    parameters: definition.parameters,
    async execute(invocationId, params) {
      const result = await definition.execute(params);
      logUnifiedMemoryEvent("tool-execute", {
        name: definition.name,
        invocationId,
        sessionId: params && typeof params === "object" && "sessionId" in params ? params.sessionId : null
      });
      return asTextResult(result);
    }
  }];
}
function asTextResult(value) {
  return {
    content: [
      {
        type: "text",
        text: typeof value === "string" ? value : JSON.stringify(value, null, 2)
      }
    ]
  };
}
function bootstrapOpenClawHost() {
  const openclawHome = (0, import_node_path3.resolve)((0, import_node_os2.homedir)(), ".openclaw");
  const extensionRoot = (0, import_node_path3.join)(openclawHome, "extensions");
  const pluginRuntimeRoot = (0, import_node_path3.resolve)((0, import_node_path3.dirname)(__dirname));
  const configPath = (0, import_node_path3.join)(openclawHome, "openclaw.json");
  const globalSkillsDir = (0, import_node_path3.join)(openclawHome, "skills");
  const bundledSkillDir = (0, import_node_path3.join)((0, import_node_path3.resolve)((0, import_node_path3.dirname)(__dirname)), "skills", SKILL_ID);
  const targetSkillDir = (0, import_node_path3.join)(globalSkillsDir, SKILL_ID);
  const forceBootstrap = process.env.OPENCLAW_BAMDRA_MEMORY_FORCE_BOOTSTRAP === "1";
  if (!forceBootstrap && !pluginRuntimeRoot.startsWith(extensionRoot)) {
    logUnifiedMemoryEvent("host-bootstrap-skipped", {
      reason: "non-installed-runtime",
      pluginRuntimeRoot
    });
    return;
  }
  if (!(0, import_node_fs2.existsSync)(configPath)) {
    logUnifiedMemoryEvent("host-bootstrap-skipped", { reason: "missing-openclaw-config" });
    return;
  }
  materializeBundledSkill(bundledSkillDir, targetSkillDir);
  const original = (0, import_node_fs2.readFileSync)(configPath, "utf8");
  const config = JSON.parse(original);
  const changed = ensureHostConfig(config, targetSkillDir);
  if (!changed) {
    logUnifiedMemoryEvent("host-bootstrap-noop", { configPath });
    return;
  }
  (0, import_node_fs2.writeFileSync)(configPath, `${JSON.stringify(config, null, 2)}
`, "utf8");
  logUnifiedMemoryEvent("host-bootstrap-updated", {
    configPath,
    targetSkillDir,
    pluginId: PLUGIN_ID
  });
}
function materializeBundledSkill(sourceDir, targetDir) {
  if (!(0, import_node_fs2.existsSync)(sourceDir)) {
    logUnifiedMemoryEvent("skill-copy-skipped", {
      reason: "missing-bundled-skill",
      sourceDir
    });
    return;
  }
  if ((0, import_node_fs2.existsSync)(targetDir)) {
    logUnifiedMemoryEvent("skill-copy-skipped", {
      reason: "target-exists",
      targetDir
    });
    return;
  }
  (0, import_node_fs2.mkdirSync)((0, import_node_path3.dirname)(targetDir), { recursive: true });
  (0, import_node_fs2.cpSync)(sourceDir, targetDir, { recursive: true });
  logUnifiedMemoryEvent("skill-copied", { sourceDir, targetDir });
}
function ensureHostConfig(config, targetSkillDir) {
  let changed = false;
  const plugins = ensureObject(config, "plugins");
  const tools = ensureObject(config, "tools");
  const skills = ensureObject(config, "skills");
  const skillsLoad = ensureObject(skills, "load");
  const agents = ensureObject(config, "agents");
  const entries = ensureObject(plugins, "entries");
  const installs = ensureObject(plugins, "installs");
  const load = ensureObject(plugins, "load");
  const slots = ensureObject(plugins, "slots");
  const pluginEntry = ensureObject(entries, PLUGIN_ID);
  const pluginConfig = ensureObject(pluginEntry, "config");
  const pluginStore = ensureObject(pluginConfig, "store");
  const pluginCache = ensureObject(pluginConfig, "cache");
  changed = ensureArrayIncludes(plugins, "allow", PLUGIN_ID) || changed;
  changed = ensureArrayIncludes(plugins, "deny", "memory-core") || changed;
  changed = ensureArrayIncludes(load, "paths", (0, import_node_path3.join)((0, import_node_os2.homedir)(), ".openclaw", "extensions")) || changed;
  changed = ensureArrayIncludes(skillsLoad, "extraDirs", (0, import_node_path3.join)((0, import_node_os2.homedir)(), ".openclaw", "skills")) || changed;
  if (slots.memory !== PLUGIN_ID) {
    slots.memory = PLUGIN_ID;
    changed = true;
  }
  if (slots.contextEngine !== PLUGIN_ID) {
    slots.contextEngine = PLUGIN_ID;
    changed = true;
  }
  if (pluginEntry.enabled !== true) {
    pluginEntry.enabled = true;
    changed = true;
  }
  if (pluginConfig.enabled !== true) {
    pluginConfig.enabled = true;
    changed = true;
  }
  if (pluginStore.provider !== "sqlite") {
    pluginStore.provider = "sqlite";
    changed = true;
  }
  if (typeof pluginStore.path !== "string" || pluginStore.path.length === 0) {
    pluginStore.path = "~/.openclaw/memory/main.sqlite";
    changed = true;
  }
  if (pluginCache.provider !== "memory") {
    pluginCache.provider = "memory";
    changed = true;
  }
  if (typeof pluginCache.maxSessions !== "number") {
    pluginCache.maxSessions = 128;
    changed = true;
  }
  if (PLUGIN_ID in installs) {
  }
  changed = ensureToolAllowlist(tools) || changed;
  changed = ensureAgentSkills(agents, SKILL_ID) || changed;
  if (!(0, import_node_fs2.existsSync)(targetSkillDir)) {
    logUnifiedMemoryEvent("host-bootstrap-skill-pending", { targetSkillDir });
  }
  return changed;
}
function ensureToolAllowlist(tools) {
  let changed = false;
  for (const toolName of REQUIRED_TOOL_NAMES) {
    changed = ensureArrayIncludes(tools, "allow", toolName) || changed;
  }
  return changed;
}
function ensureAgentSkills(agents, skillId) {
  const list = Array.isArray(agents.list) ? agents.list : [];
  let changed = false;
  for (const item of list) {
    if (!item || typeof item !== "object") {
      continue;
    }
    const agent = item;
    const currentSkills = Array.isArray(agent.skills) ? [...agent.skills] : [];
    if (!Array.isArray(agent.skills)) {
      agent.skills = currentSkills;
      changed = true;
    }
    if (!currentSkills.includes(skillId)) {
      currentSkills.push(skillId);
      agent.skills = currentSkills;
      changed = true;
    }
  }
  return changed;
}
function ensureObject(parent, key) {
  const current = parent[key];
  if (current && typeof current === "object" && !Array.isArray(current)) {
    return current;
  }
  const next = {};
  parent[key] = next;
  return next;
}
function ensureArrayIncludes(parent, key, value) {
  const current = Array.isArray(parent[key]) ? [...parent[key]] : [];
  if (current.includes(value)) {
    if (!Array.isArray(parent[key])) {
      parent[key] = current;
    }
    return false;
  }
  current.push(value);
  parent[key] = current;
  return true;
}
// Annotate the CommonJS export names for ESM import in node:
module.exports = {activate,
  register};
